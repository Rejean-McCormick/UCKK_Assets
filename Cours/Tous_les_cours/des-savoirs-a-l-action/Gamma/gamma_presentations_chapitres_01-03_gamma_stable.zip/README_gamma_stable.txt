Versions Gamma stabilisées : aucune carte-titre seule, cartes calibrées pour limiter les ajouts/suppressions automatiques de Gamma. Les séparateurs --- marquent les cartes.
