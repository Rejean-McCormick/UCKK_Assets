# **01. Introduction générale**

**Rôle du chapitre :** Orienter

## **1.0 Objectifs du chapitre**

À la fin de ce chapitre, l’étudiant devrait être capable de :

* expliquer à quoi sert le guide ;
* distinguer la méthode générale du cours et le cas filé utilisé pour l’apprendre ;
* comprendre la transformation centrale du manuel ;
* nommer les principales précautions éthiques et méthodologiques ;
* décrire le travail final en termes simples ;
* retenir les premières confusions à éviter.

---

## **1.1 Situer — Pourquoi ce guide existe**
### **1.1.1 Idée centrale**

Ce guide propose une méthode pour passer d’une situation confuse à une compréhension plus claire, puis d’une compréhension plus claire à une action prudente, documentée et révisable.

Dans beaucoup de dossiers collectifs, le problème n’est pas seulement l’absence d’information. Le problème est souvent la faiblesse des passages entre ce qui existe déjà et ce qui devient réellement utile. Des informations circulent, mais restent dispersées. Des personnes savent, mais ne sont pas suffisamment écoutées. Des ressources existent, mais ne sont pas reconnues à temps. Des décisions sont prises, mais leurs effets ne sont pas bien suivis. Des traces s’accumulent, mais ne deviennent pas mémoire utile.

### **1.1.1 Idée centrale** (suite)

Le guide existe pour travailler ces passages. Il n’enseigne pas comment imposer une réponse rapide. Il enseigne comment construire une démarche responsable à partir d’éléments déjà présents : ressources, observations, témoignages, contraintes, désaccords, options, limites et traces.

---

### **1.1.2 Contexte de départ**

Le point de départ du cours est simple : beaucoup de situations échouent moins par manque absolu de matière que par défaut d’organisation, d’écoute, de distinction, de choix explicite et de mémoire. On agit trop vite, ou trop tard. On confond hypothèse et fait. On traite une solution comme si elle allait de soi. On oublie de prévoir les impacts. On archive sans réellement apprendre.

Ce guide répond à cette difficulté en proposant une progression contrôlée. L’étudiant apprendra à observer, écouter, inventorier, distinguer, comparer, choisir, agir, corriger et transmettre prudemment. Cette logique rejoint l’ambition pédagogique de l’UCKK : transformer des savoirs en capacité d’agir, sans confondre l’école avec l’ensemble du mouvement kOA.

---

### **1.1.3 Ce que le guide cherche à former**

Le guide cherche à former une posture de travail plutôt qu’un réflexe d’opinion. L’étudiant doit apprendre à :

* ralentir avant de conclure ;
* reconnaître ce qui existe déjà avant d’annoncer ce qui manque ;
* distinguer les éléments d’un dossier au lieu de les mélanger ;
* explorer plusieurs options au lieu de courir vers la première ;
* rendre un choix explicable ;
* transformer une décision en premier geste concret ;
* garder une trace utile de ce qui a été appris.

Autrement dit, le guide ne forme pas seulement à analyser. Il forme à faire passer une matière dispersée vers une action responsable, puis vers une mémoire réutilisable.

---

### **1.1.4 Phrase d’orientation**

Ce guide n’enseigne pas comment imposer une solution. Il enseigne comment préparer une action responsable à partir de ressources, d’observations, de choix prudents et de traces utiles.

## **1.2 Distinguer — Ce que le guide est et n’est pas**

### **1.2.1 Ce que le guide est**

Ce guide est :

* un guide d’apprentissage ;
* une méthode de clarification ;
* une préparation à l’action prudente ;
* un outil de production progressive ;
* une aide à la décision révisable ;
* une manière d’organiser des traces pour qu’elles deviennent utiles.

Il aide l’étudiant à passer d’un dossier dispersé à une compréhension plus solide, puis d’une compréhension plus solide à une action mieux justifiée. Il insiste sur la relation entre méthode, responsabilité et contexte. Cette prudence rejoint les approches non extractives et relationnelles, qui rappellent qu’un savoir ne peut pas être séparé de ses conditions d’usage, des personnes concernées et des responsabilités qui accompagnent sa circulation (Smith, 2021 ; Wilson, 2008 ; Kovach, 2021).

---

### **1.2.2 Ce que le guide n’est pas**

Ce guide n’est pas :

* un protocole universel ;
* un document de gouvernance kOA ;
* un manuel sur les cultures autochtones ;
* un outil d’extraction des savoirs ;
* une procédure pour décider à la place des personnes concernées ;
* une autorisation de recueillir, utiliser ou diffuser des informations sensibles ;
* un manuel technique sur l’intelligence artificielle ;
* un remplacement des règles locales, professionnelles, juridiques ou éthiques.

Il ne donne pas le droit de parler à la place des autres. Il ne transforme pas une information disponible en information librement réutilisable. Il ne dispense jamais de vérifier les autorisations, les limites de diffusion, les contextes de production ni les responsabilités de protection.

---

### **1.2.2 Ce que le guide n’est pas** (suite)

Cette vigilance rejoint les principes de consentement, d’engagement communautaire, de gouvernance des données et de responsabilité présents dans l’EPTC 2, OCAP® et les principes CARE (Groupe en éthique de la recherche, 2022 ; First Nations Information Governance Centre, n.d. ; Carroll et al., 2020).

---

### **1.2.3 Distinctions importantes à garder dès le départ**

Plusieurs confusions doivent être évitées dès l’ouverture du cours.

| À ne pas confondre | Pourquoi c’est important |
| :---- | :---- |
| Information / connaissance | Une information doit être située, vérifiée et interprétée avant d’être tenue pour solide. |
| Écoute / extraction | Écouter ne donne pas automatiquement le droit d’utiliser, citer ou diffuser. |
| Hypothèse / fait | Une hypothèse peut orienter l’enquête, mais elle ne doit pas être présentée comme un fait établi. |
| Solution / choix responsable | Une solution doit être comparée, justifiée et limitée avant de devenir un choix. |
| Action / impact | Une action produit des effets directs, indirects et parfois invisibles. |
| Archive / mémoire utile | Une archive n’aide pas automatiquement à mieux agir ; elle doit être organisée, contextualisée et protégée. |
| Critique / accusation | Une critique peut ouvrir l’analyse ; une accusation exige des preuves et une qualification plus rigoureuse. |

---

### **1.2.3 Distinctions importantes à garder dès le départ** (suite)

Dans le Grand Dossier COVID, ces distinctions sont décisives. Dire qu’une mesure a produit des effets négatifs n’est pas la même chose que démontrer qu’elle était injustifiée. Dire qu’une institution a mal communiqué n’est pas la même chose que prouver une intention de nuire. Dire qu’une population a perdu confiance n’explique pas encore pourquoi cette confiance s’est brisée.

---

### **1.2.4 Point de vigilance**

Tout ce qui existe, se dit ou se trouve dans un dossier n’est pas automatiquement utilisable, partageable ou réutilisable.

## **1.3 Transformer — La transformation centrale du guide**

### **1.3.1 Schéma central**

Information dispersée
*→ compréhension prudente*
*→ choix justifié*
*→ action responsable*
*→ mémoire utile*

---

### **1.3.2 Explication simple**

**Information dispersée → compréhension prudente**
L’étudiant commence par reconnaître ce qui existe déjà : personnes, ressources, documents, récits, données, critiques, expériences et traces. Il apprend à situer les sources, à écouter avec méthode et à distinguer les faits des hypothèses.

**Compréhension prudente → choix justifié**
Une fois la situation mieux comprise, l’étudiant n’est pas invité à courir vers la première solution. Il doit explorer plusieurs options, les comparer et retenir un choix qu’il peut expliquer.

***Choix justifié → action responsable***
*Un choix doit ensuite devenir un premier geste concret : qui fait quoi, avec quelles ressources, dans quel délai, avec quelles limites et quelles responsabilités.*

---

### **1.3.2 Explication simple** (suite)

**Action responsable → mémoire utile**
Enfin, une action responsable laisse une trace utilisable. Elle permet de retenir ce qui a été tenté, ce qui a fonctionné, ce qui a échoué, ce qui doit être corrigé et ce qui doit être transmis ou protégé.

Chaque passage demande une méthode. Une information ne devient pas automatiquement une compréhension. Une compréhension ne devient pas automatiquement un choix. Un choix ne devient pas automatiquement une action. Une action ne devient pas automatiquement une mémoire.

---

### **1.3.3 Lien avec le standard UCKK**

Le guide suit le standard pédagogique UCKK : orienter, situer, distinguer, transformer, produire, évaluer, mémoriser, projeter et référencer. Il ne s’agit pas seulement de présenter des notions. Il s’agit d’apprendre des passages contrôlés entre matière, compréhension, décision, action et mémoire.

Cette logique rejoint aussi le cycle kOA :

Connaître
*→ Choisir*
*→ Agir*
*→ Se souvenir*

Le manuel reprend cette dynamique dans un cadre pédagogique : il forme à rendre ces passages plus lisibles, plus prudents et plus révisables.

### **1.3.4 Phrase à retenir**

Une démarche responsable ne saute pas directement du problème à la solution. Elle passe par les ressources, l’écoute, la clarification, l’exploration, le choix, l’action et la mémoire.

---

## **1.4 Produire — Ce que l’étudiant devra faire**
### **1.4.1 Le cas filé du cours**

Le guide utilise le **Grand Dossier COVID** comme cas filé principal.

Le but n’est pas de trancher toutes les controverses médicales, scientifiques ou politiques liées à la pandémie. Le but est d’étudier une crise réelle dans laquelle des sociétés ont dû connaître rapidement, choisir sous pression, agir à grande échelle et se souvenir de ce qui avait été appris.

Le cas part d’une hypothèse critique : la gestion de la pandémie a révélé des faiblesses importantes de préparation, de communication, de proportionnalité, d’écoute, de suivi des impacts et de mémoire institutionnelle. Cette hypothèse ne doit pas être répétée comme un slogan. Elle doit être travaillée comme un dossier.

La règle de méthode est donc la suivante :

La critique est permise. L’accusation doit être documentée. L’indignation doit être transformée en méthode.

---

### **1.4.1 Le cas filé du cours** (suite)

L’étudiant choisira un angle précis du Grand Dossier COVID — par exemple les écoles, les aînés, la santé mentale, les travailleurs essentiels, la communication publique, les décisions locales, les données disponibles, les bilans post-crise ou la mémoire institutionnelle — afin d’appliquer une méthode générale à un cas concret.

---

### **1.4.2 Travail final annoncé**

Le travail final du cours consistera à transformer un aspect du Grand Dossier COVID en piste d’action responsable.

L’étudiant n’aura pas à produire une vérité totale sur la pandémie. Il devra produire une démarche claire, prudente, documentée et révisable à partir d’un angle précis.

---

### **1.4.3 Les éléments du travail final**

Le travail final comprendra :

1. une situation choisie ;
2. un inventaire des ressources existantes ;
3. des notes d’écoute ou d’observation ;
4. une distinction entre faits, hypothèses et interprétations ;
5. un inventaire de solutions possibles ;
6. un choix justifié ;
7. une prévision des impacts ;
8. un plan d’action minimal ;
9. un dossier dormant ou une information existante à réactiver ;
10. une proposition de mémoire utile ;
11. un retour réflexif sur la manière de connaître, choisir, agir et se souvenir.

---

### **1.4.4 Livrables intermédiaires**

Les productions seront construites progressivement.

| Partie du guide | Production principale |
| :---- | :---- |
| Partie 1 | Carte des ressources et notes d’écoute |
| Partie 2 | Inventaire des solutions et choix justifié |
| Partie 3 | Plan d’action et grille d’impacts |
| Partie 4 | Fiche de dossier dormant et mémoire utile |
| Partie 5 | Travail final assemblé |

Chaque chapitre ajoutera donc une pièce identifiable au dossier final. Le manuel ne demande pas seulement de réfléchir ; il demande de produire des traces réutilisables.

---

### **1.4.5 Attente principale**

Le travail final ne sera pas évalué parce qu’il propose une solution parfaite, mais parce qu’il montre une démarche claire, prudente, responsable et révisable.

## **1.5 Retenir — Les phrases clés de l’introduction**

### **1.5.1 Phrase maîtresse**

Le but n’est pas de produire une réponse parfaite. Le but est de produire une démarche claire, prudente, révisable et utile.

---

### **1.5.2 Formule courte du guide**

Inventorier avant d’analyser.
Écouter avant d’interpréter.
Explorer avant de choisir.
Prévoir avant d’agir.
Documenter avant de réutiliser.

### **1.5.3 Ce que l’étudiant doit retenir**

À la fin de l’introduction, l’étudiant doit comprendre que :

* comprendre demande du temps ;
* écouter ne veut pas dire posséder ;
* une information disponible n’est pas automatiquement utilisable ;
* une solution doit être comparée ;
* une action doit prévoir ses impacts ;
* une mémoire utile protège autant qu’elle transmet.

---

### **1.5.4 Erreurs à éviter dès le départ**

Dès l’ouverture du guide, plusieurs erreurs doivent être évitées :

* vouloir résoudre trop vite ;
* croire qu’une information disponible est automatiquement réutilisable ;
* traiter un silence comme une absence d’information ;
* confondre hypothèse et fait ;
* oublier les ressources déjà présentes ;
* produire un plan sans prévoir les impacts ;
* confondre archive et mémoire utile ;
* utiliser le vocabulaire de la justice, de la responsabilité ou de la décolonisation de manière vague ou décorative (Tuck & Yang, 2012).

---

## **1.6 Référencer — Références mobilisées dans l’introduction**
### **1.6.1 Références de fond**

Cette introduction s’appuie notamment sur :

### **1.6.1 Références de fond** (suite)

* **Linda Tuhiwai Smith** — pour la critique des recherches extractives, la prudence méthodologique et la responsabilité envers les savoirs situés ;
* **Shawn Wilson** — pour l’idée que la recherche est relationnelle et engage une responsabilité envers les personnes, les lieux et les savoirs ;
* **Margaret Kovach** — pour l’importance de la conversation, du contexte, du récit et de la validation dans les méthodologies autochtones ;
* **Tuck & Yang** — pour la vigilance contre les usages vagues, décoratifs ou dépolitisés de la décolonisation ;
* **EPTC 2** — pour les principes de consentement, d’engagement communautaire, de respect et de protection des savoirs dans la recherche avec des êtres humains ;
* **OCAP®** — pour la propriété, le contrôle, l’accès et la possession des informations des Premières Nations ;
* **CARE** — pour les droits collectifs, l’autorité de contrôle, la responsabilité et l’éthique dans la gouvernance des données.

---

### **1.6.2 Formule de fin de chapitre**

Cette introduction s’appuie notamment sur Smith, Wilson, Kovach, Tuck & Yang, l’EPTC 2, OCAP® et les principes CARE. Voir la bibliographie commentée pour les références complètes.

## **1.7 Transition vers le chapitre 2**

Ce chapitre a orienté le guide : il a présenté la méthode, le cas filé, les premières distinctions et le travail final.

Le chapitre suivant commencera le travail concret. Avant de dénoncer ce qui manque, il faudra apprendre à reconnaître ce qui existe déjà.

Dans le Grand Dossier COVID, cela signifie poser une question plus exigeante que *qu’est-ce qui a échoué ?* :

Quelles ressources existaient déjà, mais ont été mal vues, mal mobilisées, mal coordonnées ou mal respectées ?
