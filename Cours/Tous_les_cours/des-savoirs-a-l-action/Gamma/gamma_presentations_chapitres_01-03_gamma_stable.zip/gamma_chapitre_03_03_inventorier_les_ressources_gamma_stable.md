# **03. Inventorier les ressources**

**Rôle du chapitre :** *Situer → Produire*

**Trajectoire du chapitre :**
Situation vague
*→ ressources repérées*
*→ ressources classées*
*→ porteurs identifiés*
*→ accès clarifiés*
*→ limites reconnues*
*→ carte des ressources disponible*

## **3.0 Objectifs du chapitre**

À la fin de ce chapitre, l’étudiant devrait être capable de :

* repérer les ressources déjà présentes dans une situation ;
* distinguer ressource, besoin et solution ;
* classer les ressources sans transformer l’inventaire en catalogue confus ;
* identifier qui porte une ressource et sous quelles conditions elle peut être mobilisée ;
* reconnaître les ressources visibles, invisibles, dormantes ou sensibles ;
* produire une carte des ressources utile pour la suite du travail.

Ce chapitre transforme le déplacement de regard du chapitre 2 en premier outil concret. On ne reste plus seulement dans la posture. On commence à construire une base de travail.

---

## **3.1 Situer — Avant d’agir, savoir ce qui existe**

### **3.1.1 Idée centrale**

Avant de demander ce qu’il faut ajouter, il faut reconnaître ce qui est déjà là.

Une situation collective ne contient pas seulement des problèmes. Elle contient aussi des personnes, des compétences, des relations, des lieux, des documents, des outils, des habitudes, des savoir-faire, des expériences passées et parfois des ressources oubliées. L’approche du développement communautaire fondé sur les ressources rappelle qu’un milieu ne doit pas être abordé uniquement par ses déficits, mais aussi par ses capacités déjà présentes (Kretzmann & McKnight, 1993).

Inventorier les ressources ne veut pas dire nier les difficultés. Cela veut dire éviter une erreur fréquente : confondre diagnostic sérieux et regard uniquement déficitaire.

---

### **3.1.2 Pourquoi commencer par les ressources**

Commencer par les ressources change la qualité de l’analyse.

Une lecture centrée seulement sur les manques conduit souvent à :

* sous-estimer les personnes concernées ;
* ignorer des appuis déjà disponibles ;
* proposer trop vite une solution extérieure ;
* répéter un travail déjà fait ;
* confondre absence de coordination et absence totale de ressources.

À l’inverse, un inventaire des ressources permet de demander :

* qu’est-ce qui existe déjà ;
* qui le porte ;
* à quoi cela peut servir ;
* dans quelles conditions cela peut être mobilisé ;
* quelles limites ou protections doivent être respectées.

Cette manière de voir prépare une action plus située, plus prudente et plus réaliste. Elle rejoint aussi les approches relationnelles de la connaissance : une ressource n’a de sens qu’en lien avec un contexte, des personnes et des responsabilités (Wilson, 2008 ; Smith, 2021).

---

### **3.1.3 Place du chapitre dans le guide**

Le chapitre 2 a déplacé le regard : ne pas commencer seulement par les problèmes.

Le chapitre 3 transforme ce déplacement en production. Il fait apparaître une première trace structurée : **la carte des ressources**.

Cette carte n’est pas encore une solution. Elle sert à mieux voir le terrain avant d’écouter plus finement les personnes, puis avant de distinguer les faits, hypothèses et interprétations. La structure attendue du chapitre et sa fonction de première vraie production sont explicitement prévues dans l’outline détaillé et dans le standard de numérotation retenu.

---

### **3.1.4 Application au Grand Dossier COVID**

Dans le Grand Dossier COVID, l’inventaire des ressources empêche de réduire la crise à une liste d’échecs. Il oblige à demander :

* quelles ressources existaient déjà avant la crise ;
* lesquelles ont été mobilisées ;
* lesquelles ont été ignorées ;
* lesquelles ont été surchargées ;
* lesquelles étaient présentes mais mal coordonnées ;
* lesquelles demeurent sensibles ou difficiles à réutiliser.

Exemples de ressources à repérer :

* plans de pandémie ;
* santé publique ;
* médecins de terrain ;
* infirmières ;
* pharmaciens ;
* écoles ;
* organismes communautaires ;
* familles ;
* municipalités ;
* radios locales ;
* réseaux de bénévoles ;
* savoirs issus d’épidémies précédentes ;
* données hospitalières ;
* lieux de distribution ;
* équipes logistiques ;
* experts critiques ;
* expériences locales.

---

## **3.2 Distinguer — Ressource, besoin, solution**

### **3.2.1 Distinctions importantes**

Avant de classer les ressources, il faut clarifier quelques distinctions simples.

| À distinguer | Pourquoi c’est important |
| :---- | :---- |
| Ressource / besoin | Une ressource est un appui existant ; un besoin indique ce qui manque ou ce qui doit être soutenu. |
| Ressource / solution | Une ressource peut aider à agir, mais elle n’est pas encore une stratégie ou une décision. |
| Présence / accès | Une ressource peut exister sans être réellement accessible. |
| Accès / permission | On peut pouvoir atteindre une ressource sans avoir le droit légitime de l’utiliser ou de la diffuser. |
| Visible / invisible | Certaines ressources sautent aux yeux ; d’autres passent par la confiance, les relations ou l’expérience locale. |
| Active / dormante | Une ressource peut être mobilisée maintenant, ou rester oubliée jusqu’à ce qu’on la relise. |
| Utile / sensible | Une ressource peut être précieuse, tout en exigeant prudence, protection ou validation. |

---

### **3.2.2 Définition de ressource**

Dans ce guide, une ressource est :

une personne, un groupe, une relation, un lieu, un document, une capacité, une expérience, un outil ou une trace qui peut soutenir la compréhension ou l’action, à condition que son usage soit situé, légitime et prudent.

Cette définition est volontairement large. Elle permet d’inclure à la fois des ressources matérielles et des ressources relationnelles, institutionnelles ou documentaires.

---

### **3.2.3 Les dix types de ressources**

Pour éviter l’effet catalogue, le chapitre utilise une typologie stable de dix types. Elle ne sert pas à compliquer l’analyse, mais à la rendre lisible.

1. **Ressources individuelles** — personnes, compétences, expériences, savoir-faire.
2. **Ressources communautaires** — organismes, groupes d’entraide, réseaux locaux.
3. **Ressources relationnelles** — liens de confiance, relais, proximités, personnes-ponts.
4. **Ressources institutionnelles** — services publics, écoles, municipalités, établissements.
5. **Ressources documentaires** — plans, bilans, rapports, statistiques, consignes, archives.
6. **Ressources logistiques** — lieux, matériel, transport, accès technique, distribution.
7. **Ressources territoriales** — proximité, dispersion, ancrage local, géographie du problème.
8. **Ressources culturelles et communicationnelles** — langues, codes, pratiques locales, médias de confiance.
9. **Ressources dormantes** — anciens bilans, plans oubliés, apprentissages non réactivés.
10. **Ressources sensibles** — données, témoignages, dossiers ou relations dont l’usage exige prudence, autorisation ou protection.

---

### **3.2.4 Ressources visibles et invisibles**

Une carte faible montre seulement les ressources officielles ou évidentes :

* institutions ;
* documents publics ;
* lieux connus ;
* programmes formels.

Une carte plus forte inclut aussi les ressources moins visibles :

* personnes de confiance ;
* savoirs pratiques ;
* expérience accumulée ;
* habitudes locales efficaces ;
* réseaux de solidarité ;
* relais informels ;
* mémoire collective.

Les approches centrées sur les dommages risquent de passer à côté de ces ressources moins visibles. Il faut donc apprendre à regarder aussi ce qui tient discrètement un milieu, sans pour autant l’idéaliser (Tuck, 2009).

---

### **3.2.5 Présence, accès, permission**

Une ressource peut être :

* présente sans être accessible ;
* accessible sans être librement réutilisable ;
* autorisée, mais trop fragile pour être mobilisée sans précaution.

| Question | Ce qu’elle vérifie | Exemple |
| :---- | :---- | :---- |
| La ressource est-elle présente ? | existence réelle de la ressource | un bilan existe-t-il vraiment ? |
| La ressource est-elle accessible ? | possibilité concrète d’y accéder | peut-on obtenir le document, joindre le service, utiliser le lieu ? |
| La ressource est-elle mobilisable avec permission ? | droit, autorisation, légitimité d’usage | a-t-on le droit d’utiliser cette donnée, cette parole, ce contact ? |

Cette distinction évite de confondre **présence** et **usage légitime**. Elle rejoint les garde-fous du guide : une information disponible n’est pas automatiquement librement réutilisable.

---

## **3.3 Transformer — De la liste à la carte**

### **3.3.1 Opération centrale**

L’opération du chapitre consiste à passer d’une liste dispersée à une **carte des ressources**.

Éléments repérés
*→ tri par type*
*→ porteurs identifiés*
*→ conditions précisées*
*→ limites reconnues*
*→ carte lisible pour la suite*

Une liste accumule. Une carte organise.

Une carte des ressources doit montrer au minimum :

* ce qui existe ;
* qui le porte ;
* à quoi cela peut servir ;
* sous quelles conditions cela peut être mobilisé ;
* ce qui doit être vérifié, protégé ou laissé de côté.

---

### **3.3.2 Étapes de transformation**

**Étape 1 — Repérer**
Lister rapidement les ressources déjà présentes, sans encore chercher l’ordre parfait.

**Étape 2 — Regrouper**
Classer les ressources par type pour éviter le mélange entre personnes, documents, lieux, données et relations.

**Étape 3 — Situer**
Identifier pour chaque ressource son porteur, son contexte et sa portée réelle.

**Étape 4 — Qualifier**
Préciser si la ressource est visible, invisible, dormante, sensible, accessible, partielle ou à vérifier.

**Étape 5 — Relire**
Se demander ce que la carte rend visible qui ne l’était pas au départ. Donald Schön rappelle que la compréhension se construit souvent en relisant l’action et ses traces, pas seulement en avançant linéairement (Schön, 1983).

---

### **3.3.3 Pourquoi cette transformation est nécessaire**

Sans cette transformation, l’étudiant risque :

* de garder une liste trop longue et inutilisable ;
* de confondre ressources fortes et ressources fragiles ;
* d’oublier les ressources invisibles ;
* de traiter toute ressource trouvée comme immédiatement mobilisable ;
* de ne pas voir ce qui manque en coordination plutôt qu’en existence ;
* de proposer une solution sans connaître réellement le terrain.

La carte n’est donc pas un luxe de présentation. C’est une manière de penser plus justement.

---

### **3.3.4 Le cas COVID comme exercice de lucidité**

Dans le cas du Grand Dossier COVID, transformer la liste en carte permet de passer d’une critique générale — *la crise a été mal gérée* — à une question plus utile :

Quelles ressources auraient pu soutenir une meilleure gestion si elles avaient été mieux reconnues, mieux coordonnées ou mieux respectées ?

Cette question rend la critique plus précise. Elle ne remplace pas l’analyse des erreurs ; elle la rend plus lisible.

---

### **3.3.5 Erreurs fréquentes**

* **Confondre ressource et solution.** Un organisme local n’est pas encore une stratégie.
* **Faire une liste trop longue et inutilisable.** Mieux vaut une carte claire qu’un inventaire sans hiérarchie.
* **N’inclure que les ressources officielles.** Les ressources relationnelles et locales comptent aussi.
* **Traiter toute ressource disponible comme automatiquement mobilisable.** L’accès et la permission doivent être vérifiés.
* **Oublier les ressources dormantes.** Un vieux plan, un ancien bilan ou une mémoire locale peuvent redevenir utiles.
* **Oublier les limites.** Une ressource peut être réelle, mais surchargée, partielle ou fragile.

---

### **3.3.6 Point de vigilance**

Une bonne carte ne sert pas à montrer qu’il existe beaucoup de choses. Elle sert à montrer **ce qui peut réellement compter pour comprendre et agir**, avec quelles conditions et quelles limites.

## **3.4 Produire — Carte des ressources**

### **3.4.1 Livrable principal**

Le livrable principal du chapitre est une **carte des ressources** liée à une situation précise.

Cette carte ne doit pas être une simple liste. Elle doit montrer :

* quelles ressources existent déjà ;
* qui les porte ;
* à quoi elles peuvent servir ;
* si elles sont réellement accessibles ;
* quelles permissions, limites ou précautions doivent être prises en compte.

La carte doit rester suffisamment courte pour être utile, mais suffisamment riche pour faire apparaître autre chose qu’un inventaire dispersé.

---

### **3.4.2 Tableau d’inventaire — Identifier les ressources**

Le premier tableau sert à nommer les ressources et à les situer.

| Ressource | Type | Porteur | À quoi cela peut servir |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Ce tableau répond à quatre questions simples :

* quelle est la ressource ;
* de quel type de ressource s’agit-il ;
* qui la porte ;
* à quoi elle peut servir.

---

### **3.4.3 Tableau d’inventaire — Vérifier les conditions d’usage**

Le second tableau sert à éviter une confusion importante : une ressource peut exister sans être réellement accessible, autorisée ou mobilisable.

| Ressource | Présente ? | Accessible ? | Permission, limite ou précaution |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Ce tableau répond à trois questions :

* la ressource existe-t-elle vraiment ;
* peut-on y accéder concrètement ;
* a-t-on le droit ou la légitimité de l’utiliser.

---

### **3.4.4 Tableau complémentaire — Ressources à vérifier**

Certaines ressources semblent importantes, mais ne peuvent pas encore être utilisées sans vérification.

| Ressource | Ce qui doit être vérifié | Qui peut valider ? | Prochaine étape |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Ce tableau sert à repérer les ressources qui demandent une étape supplémentaire avant d’être mobilisées.

---

### **3.4.5 Tableau complémentaire — Ressources sensibles**

Certaines ressources peuvent être utiles, mais elles exigent une protection particulière.

| Ressource | Pourquoi elle est sensible | Qui peut décider de son usage ? | Précaution |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Une ressource sensible n’est pas une ressource interdite.
C’est une ressource dont l’usage doit être encadré, limité ou validé.

---

### **3.4.6 Exemple appliqué au Grand Dossier COVID**

**Situation choisie :** effets des fermetures d’écoles sur les jeunes et leurs familles.

#### **A. Identification des ressources**

| Ressource | Type | Porteur | À quoi cela peut servir |
| :---- | :---- | :---- | :---- |
| enseignants | individuelle / institutionnelle | écoles | observer les besoins des jeunes au quotidien |
| parents | individuelle / relationnelle | familles | comprendre les effets à domicile |
| données scolaires | documentaire | établissements / services scolaires | repérer des signes d’absentéisme ou de décrochage |
| organismes jeunesse | communautaire | organismes locaux | offrir du soutien, du relais et de l’accompagnement |
| professionnels psychosociaux | individuelle / institutionnelle | réseau de santé / écoles | apporter une expertise clinique et un suivi |
| bilans post-crise | dormante / documentaire | institutions / chercheurs | réactiver des apprentissages déjà formulés |
| lieux communautaires | logistique / territoriale | municipalités / organismes | organiser des rencontres, du soutien ou des ateliers |
| relations de confiance | relationnelle | familles / quartiers / milieux | permettre une parole plus libre et une meilleure remontée d’information |

---

#### **B. Conditions d’usage**

| Ressource | Présente ? | Accessible ? | Permission, limite ou précaution |
| :---- | :---- | :---- | :---- |
| enseignants | Oui | Oui | usage légitime dans leur rôle ; attention à la surcharge |
| parents | Oui | Variable | consultation à organiser ; fatigue et diversité des situations |
| données scolaires | Oui | Partielle | usage encadré ; confidentialité à respecter |
| organismes jeunesse | Oui | Variable | selon les ententes locales ; capacité inégale selon les milieux |
| professionnels psychosociaux | Oui | Limitée | selon disponibilité ; délais et surcharge possibles |
| bilans post-crise | Oui | Variable | utilisables si source publique ou autorisée ; validité à vérifier |
| lieux communautaires | Oui | Variable | coordination locale nécessaire ; accès territorial inégal |
| relations de confiance | Oui | Fragile | non réutilisables sans prudence ; lentes à construire |

---

#### **C. Ressources à vérifier**

| Ressource | Ce qui doit être vérifié | Qui peut valider ? | Prochaine étape |
| :---- | :---- | :---- | :---- |
| données scolaires | niveau d’accès, degré d’agrégation et règles de confidentialité | établissements / services scolaires | identifier les données utilisables sans exposer les élèves |
| bilans post-crise | existence, date, portée et fiabilité | institutions / chercheurs | retrouver les bilans pertinents et vérifier leur actualité |
| organismes jeunesse | disponibilité réelle et capacité d’accueil | organismes locaux | vérifier les ressources encore actives et accessibles |

#### **D. Ressource sensible à protéger ou à encadrer**

| Ressource | Pourquoi elle est sensible | Qui peut décider de son usage ? | Précaution |
| :---- | :---- | :---- | :---- |
| données scolaires individuelles | elles peuvent exposer des élèves ou des familles | établissements / autorités responsables | anonymiser, limiter l’accès, vérifier les autorisations |

---

### **3.4.7 Mini-exercice**

À partir de la situation choisie :

1. écrire une liste brute d’au moins 20 ressources possibles ;
2. choisir les 8 à 12 ressources les plus utiles pour la carte ;
3. les classer dans les catégories du tableau ;
4. identifier au moins cinq porteurs de ressources ;
5. préciser les conditions d’accès ;
6. identifier au moins trois limites ou précautions ;
7. repérer au moins une ressource dormante ;
8. repérer au moins une ressource sensible ;
9. choisir trois ressources à vérifier avant de continuer.

**Production attendue :**

* le tableau d’identification des ressources ;
* le tableau des conditions d’usage ;
* le tableau des ressources à vérifier ;
* le tableau des ressources sensibles, si nécessaire ;
* une courte note de 8 à 10 lignes répondant à la question suivante :

**Qu’est-ce que cet inventaire m’a permis de voir que je n’aurais pas vu en commençant seulement par le problème ?**

---

### **3.4.8 Critères de réussite**

Le travail est réussi si la carte :

* distingue clairement les ressources des besoins et des solutions ;
* montre plusieurs types de ressources, pas une seule famille ;
* identifie les porteurs des ressources ;
* précise les conditions d’accès ;
* distingue présence, accessibilité et permission d’usage ;
* nomme les limites principales ;
* repère au moins une ressource dormante ou invisible ;
* repère au moins une ressource sensible, si elle existe ;
* reste lisible et utile pour la suite du travail.

Une bonne carte des ressources ne cherche pas à tout montrer.
Elle cherche à rendre visibles les appuis qui peuvent réellement compter pour comprendre et agir prudemment.

---

## **3.5 Retenir — Ce qu’une carte permet et ne permet pas**

### **3.5.1 Phrase clé**

Une carte des ressources ne résout pas le problème. Elle empêche de croire qu’il n’existe rien avant la solution.

### **3.5.2 Trois idées à retenir**

* Une situation contient plus que ses manques.
* Une ressource n’est utile que si son porteur, son accès et ses limites sont situés.
* Une bonne carte prépare l’écoute, la distinction et, plus tard, le choix.

---

### **3.5.3 Erreurs à éviter**

* réduire la situation à un inventaire de déficits ;
* transformer l’inventaire en catalogue trop long ;
* oublier les ressources invisibles ou dormantes ;
* confondre présence et permission ;
* produire une carte sans limites ni précautions.

### **3.5.4 Transition vers l’écoute**

Une carte des ressources ne suffit pas.

Elle montre ce qui existe, mais elle ne dit pas encore ce que les personnes vivent, comprennent, craignent, contestent ou jugent prioritaire.

Après avoir repéré les ressources, il faut donc apprendre à écouter.

---

## **3.6 Référencer — Références mobilisées**

### **3.6.1 Références principales**

Cette partie s’appuie notamment sur :

* **Kretzmann & McKnight** : développement communautaire fondé sur les ressources ;
* **Shawn Wilson** : savoir relationnel, contexte et responsabilité ;
* **Linda Tuhiwai Smith** : prudence méthodologique, non-extraction et conditions d’usage ;
* **Donald Schön** : compréhension progressive, relecture de l’action et apprentissage par ajustement.

---

### **3.6.2 Références secondaires possibles**

À mentionner seulement si nécessaire :

* **Eve Tuck** : ne pas réduire un milieu à ses dommages ;
* **Margaret Kovach** : contexte, conversation, récit et validation ;
* **OCAP® / CARE** : accès, autorité, contrôle, protection et gouvernance des informations.

Les références complètes se trouvent dans la bibliographie commentée.

---

## **3.7 Livrable du chapitre**

**Livrable attendu :** une carte des ressources de 8 à 12 entrées, liée à un angle précis du cas étudié.

**Format minimal attendu :**

* un titre de situation ;
* un tableau d’inventaire ;
* trois ressources à vérifier ;
* une ressource sensible à protéger ou à encadrer ;
* une courte note de lecture : *qu’est-ce que cette carte rend visible ?*

## **3.8 Transition vers le chapitre 4**

*03. Inventorier les ressources*
*→ 04. Écouter avec attention*

Une carte des ressources ouvre le terrain. L’écoute lui donne du sens.
