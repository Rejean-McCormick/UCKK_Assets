# **02. Commencer par ce qui existe déjà**

**Rôle du chapitre :** Situer

**Trajectoire du chapitre :**

Diagnostic par les manques
*→ reconnaissance des ressources déjà présentes*
*→ première posture d’attention responsable*

## **2.0 Objectifs du chapitre**

À la fin de ce chapitre, l’étudiant devrait être capable de :

* reconnaître qu’une situation ne se résume pas à ses problèmes ;
* repérer les ressources déjà présentes dans un milieu ;
* distinguer problème, contexte, manque, ressource, capacité et urgence ;
* reformuler une situation sans réduire les personnes à leurs difficultés ;
* produire une première description orientée vers les ressources ;
* appliquer cette posture au Grand Dossier COVID.

Ce chapitre ouvre la première partie du guide. Il ne demande pas encore de choisir une solution. Il demande d’apprendre à voir autrement : avant d’ajouter, de corriger ou de dénoncer, il faut reconnaître ce qui existe déjà. Cette fonction, cette progression et cette hiérarchie de titres suivent le standard retenu pour le guide.

---

## **2.1 Situer — Le réflexe de commencer par les problèmes**

### **2.1.1 Idée centrale**

Beaucoup de démarches commencent par une question apparemment évidente :

Quel est le problème ?

Cette question peut être utile. Elle permet de nommer une difficulté, une tension, une urgence ou une souffrance. Mais si elle est posée seule, elle déforme le regard. Elle pousse à voir d’abord les déficits, les blessures, les absences et les dysfonctionnements.

Une situation devient alors un inventaire de manques :

* manque de personnel ;
* manque de coordination ;
* manque d’information ;
* manque de confiance ;
* manque de préparation ;
* manque de ressources ;
* manque de temps ;
* manque de leadership.

Ces manques peuvent être réels. Le problème n’est pas de les nommer. Le problème est de ne voir qu’eux.

---

### **2.1.2 Pourquoi ce réflexe pose problème**

Une lecture uniquement déficitaire produit souvent plusieurs effets :

* elle décrit les personnes à partir de ce qui leur manque ;
* elle sous-estime les savoirs déjà présents ;
* elle oublie les relations locales ;
* elle rend invisibles les capacités du milieu ;
* elle prépare trop vite une solution extérieure ;
* elle transforme les personnes concernées en objets d’intervention ;
* elle affaiblit la qualité même de la critique.

---

### **2.1.2 Pourquoi ce réflexe pose problème** (suite)

L’approche du développement communautaire fondé sur les ressources rappelle qu’un milieu ne doit pas être abordé uniquement par ses déficits, mais aussi par ses capacités, ses relations et ses appuis déjà présents (Kretzmann & McKnight, 1993). Dans le même esprit, les méthodologies relationnelles et non extractives insistent sur le fait qu’on ne comprend pas une situation en réduisant les personnes à leurs blessures ou à leurs manques ; il faut aussi reconnaître les contextes, les relations, les savoirs situés et les conditions d’usage de ce qui est observé (Smith, 2021 ; Wilson, 2008 ; Kovach, 2021).

---

### **2.1.3 Application au Grand Dossier COVID**

Dans le Grand Dossier COVID, le réflexe immédiat consiste souvent à commencer par les défaillances :

* les règles ont changé ;
* les messages ont parfois été contradictoires ;
* des personnes ont été isolées ;
* des familles ont été épuisées ;
* des travailleurs ont été exposés ;
* des impacts sociaux ont été mal anticipés ;
* la confiance envers les institutions a été fragilisée.

Ces constats peuvent être importants. Mais une critique qui s’arrête là reste incomplète.

La question de ce chapitre est plus exigeante :

Quelles ressources existaient déjà, mais ont été mal vues, mal mobilisées, mal coordonnées, mal protégées ou mal respectées ?

---

### **2.1.3 Application au Grand Dossier COVID** (suite)

Poser cette question ne blanchit pas les erreurs. Au contraire, cela les rend plus lisibles. Une gestion de crise peut être critiquée plus fortement lorsqu’on montre non seulement ce qui a manqué, mais aussi ce qui existait déjà et n’a pas été suffisamment reconnu. C’est le rôle du cas filé dans ce chapitre.

---

## **2.2 Distinguer — Problème, contexte, manque, ressource, capacité**
### **2.2.1 Distinctions de base**

Commencer par ce qui existe déjà exige des distinctions simples. Sans elles, l’étudiant risque de confondre plusieurs réalités.

### **2.2.1 Distinctions de base** (suite)

| À distinguer | Pourquoi c’est important |
| :---- | :---- |
| Problème / contexte | Le problème est ce qui dérange. Le contexte aide à comprendre pourquoi cela arrive. |
| Manque / ressource | Un manque signale une absence. Une ressource indique un appui possible pour comprendre ou agir. |
| Vulnérabilité / capacité | Une personne peut vivre une difficulté tout en portant des savoirs, des compétences ou des relations importantes. |
| Besoin / potentiel | Un besoin appelle une réponse. Un potentiel indique une possibilité à développer ou à soutenir. |
| Ressource / solution | Une ressource peut soutenir l’action, mais elle n’est pas encore une solution. |
| Existence / disponibilité | Une ressource peut exister sans être accessible, autorisée, coordonnée ou utilisable. |
| Urgence / priorité | Ce qui est urgent attire l’attention, mais n’épuise pas toujours ce qui est important. |

---

### **2.2.2 Deux erreurs opposées**

Ce chapitre veut éviter deux erreurs opposées.

**Première erreur :** ne voir que les problèmes.
On obtient alors un diagnostic brutal, parfois juste, mais appauvri. Les personnes sont décrites par leurs limites et le milieu paraît vide.

**Deuxième erreur :** idéaliser les ressources.
On parle alors de forces sans nommer les contraintes, les conflits, l’épuisement, l’inégalité d’accès ou les limites d’usage.

La posture juste n’est ni le déni du problème ni l’éloge abstrait des forces. Elle consiste à tenir ensemble :

* les difficultés réelles ;
* les ressources déjà présentes ;
* les limites de ces ressources ;
* les conditions de leur mobilisation.

---

### **2.2.3 Une ressource n’est pas automatiquement utilisable**

Une ressource peut exister sans être :

* visible ;
* coordonnée ;
* disponible au bon moment ;
* accessible à tous ;
* légitime dans le contexte ;
* partageable sans risque ;
* suffisante pour répondre seule au problème.

Autrement dit :

ce qui existe déjà n’est pas automatiquement mobilisable.

Cette distinction est importante pour la suite du guide. Elle prépare le passage du chapitre 2 au chapitre 3 : voir les ressources ne suffit pas, il faudra ensuite les inventorier, les situer, préciser qui les porte, à quelles conditions elles peuvent être mobilisées et quelles précautions doivent être respectées.

---

## **2.3 Transformer — Changer le regard avant d’agir**

### **2.3.1 La transformation centrale du chapitre**

La transformation de ce chapitre est simple, mais décisive :

*description par les manques → description par les ressources*

Ce déplacement ne supprime pas la critique. Il l’améliore.

Une critique faible dit seulement :

rien n’allait.

Une critique plus forte demande :

* qu’est-ce qui manquait réellement ;
* qu’est-ce qui existait déjà ;
* qui portait ces ressources ;
* pourquoi elles n’ont pas suffi ;
* pourquoi elles n’ont pas été reconnues, coordonnées ou protégées ;
* quelles relations ont été ignorées ;
* quelles capacités ont été sous-estimées.

---

### **2.3.2 Ce que ce changement produit**

Changer le regard avant d’agir permet de :

* décrire une situation avec plus de justesse ;
* éviter de réduire les personnes à leurs blessures ;
* identifier des appuis déjà présents ;
* préparer une critique plus documentée ;
* éviter de proposer trop vite une solution importée ;
* mieux voir ce qui devra être inventorié au chapitre suivant.

Dans le cas du Grand Dossier COVID, ce changement de regard mène d’une formule vague — *tout a mal été géré* — à une question de travail plus précise :

Quels appuis existaient déjà dans les institutions, les milieux de vie, les communautés, les familles, les territoires et les documents, et qu’est-ce qui a empêché qu’ils soutiennent mieux l’action ?

---

### **2.3.3 Exemples de ressources à reconnaître dans le cas COVID**

Selon l’angle étudié, les ressources déjà présentes pouvaient inclure :

* des plans de pandémie ;
* des équipes de santé publique ;
* des soignants de terrain ;
* des pharmaciens ;
* des enseignants ;
* des directions d’école ;
* des organismes communautaires ;
* des familles ;
* des proches aidants ;
* des municipalités ;
* des réseaux de bénévoles ;
* des radios locales ;
* des lieux de distribution ;
* des données hospitalières ;
* des bilans locaux ;
* des critiques précoces ;
* des savoirs pratiques issus du terrain ;
* des documents oubliés ou peu relus.

Le travail de l’étudiant n’est pas encore de tout classer. Il est d’apprendre à voir que le terrain n’est pas vide. Le chapitre 3 transformera cette reconnaissance en carte des ressources. Le cas filé prévoit explicitement ce passage d’une critique générale de la crise à une question plus précise sur les ressources mal reconnues ou mal mobilisées.

---

## **2.4 Produire — Exercice de double description**

### **2.4.1 Consigne**

Choisis une situation précise liée au Grand Dossier COVID.

Exemples possibles :

* fermetures d’écoles ;
* isolement des aînés ;
* communication publique ;
* surcharge du personnel soignant ;
* fatigue parentale ;
* travailleurs essentiels ;
* accès inégal au numérique ;
* perte de confiance envers les institutions.

Rédige ensuite **deux descriptions courtes** de la même situation.

---

### **2.4.2 Description A — Lecture par les manques**

Écris un court paragraphe qui décrit la situation en commençant par ce qui manque, ce qui échoue ou ce qui est brisé.

### **2.4.3 Description B — Lecture par les ressources**

Réécris ensuite la même situation en commençant par les ressources déjà présentes, sans nier les problèmes.

Ta seconde description doit essayer de répondre aux questions suivantes :

* qui ou quoi était déjà là ;
* quels savoirs existaient déjà ;
* quelles relations pouvaient soutenir l’action ;
* quelles institutions, quels lieux ou quels documents pouvaient servir d’appui ;
* quelles ressources ont été mal vues, mal coordonnées ou mal respectées ;
* quelles limites empêchaient leur mobilisation complète.

---

### **2.4.4 Exemple appliqué**

**Situation choisie :** fatigue des familles pendant les fermetures d’écoles.

**Description A — par les manques**

Les fermetures d’écoles ont épuisé les familles. Il manquait de stabilité, de soutien, de répit, d’accompagnement et de coordination. Les parents ont dû tout porter à la fois, souvent sans aide suffisante.

**Description B — par les ressources**

Les familles n’étaient pas seules à partir de rien. Il existait déjà des enseignants, des directions d’école, des organismes jeunesse, des réseaux de parents, des outils numériques, des professionnels psychosociaux, des lieux communautaires et des expériences locales de soutien. Le problème n’était pas seulement l’absence de ressources ; c’était aussi leur coordination inégale, leur accessibilité variable, leur surcharge et le fait que certaines d’entre elles ont été trop peu reconnues ou trop tard mobilisées.

---

### **2.4.5 Grille rapide pour l’exercice**

| Élément à repérer | Question |
| :---- | :---- |
| Problème visible | Qu’est-ce qui semble manquer ou échouer ? |
| Ressources présentes | Qui ou quoi était déjà là ? |
| Porteurs | Qui porte réellement ces ressources ? |
| Conditions | À quelles conditions ces ressources sont-elles accessibles ? |
| Limites | Pourquoi ces ressources n’ont-elles pas suffi ? |
| Hypothèse de travail | Qu’est-ce que cette double description change dans la compréhension de la situation ? |

---

## **2.5 Retenir — Ce qu’il faut garder du chapitre**

### **2.5.1 Phrase clé**

Commencer par ce qui existe déjà ne nie pas les problèmes ; cela empêche de mal voir la situation.

### **2.5.2 Ce que l’étudiant doit retenir**

À la fin du chapitre, l’étudiant doit comprendre que :

* une situation ne se résume pas à ses manques ;
* une critique plus forte identifie aussi les ressources ignorées ;
* une ressource n’est pas une solution ;
* ce qui existe n’est pas automatiquement disponible ;
* les personnes concernées ne doivent pas être réduites à leurs difficultés ;
* le regard posé au départ influence toute la suite du travail.

---

### **2.5.3 Erreurs fréquentes**

* croire que regarder les ressources revient à minimiser les dommages ;
* faire l’éloge abstrait des forces sans nommer les limites ;
* confondre ressource et solution ;
* prendre une ressource existante pour une ressource accessible ;
* réduire une population à ses souffrances ;
* dénoncer une crise sans demander quelles capacités avaient déjà été négligées.

---

## **2.6 Référencer — Références mobilisées**

Ce chapitre s’appuie principalement sur l’approche du développement communautaire fondé sur les ressources, qui invite à commencer par les capacités existantes d’un milieu plutôt que par ses seuls déficits (Kretzmann & McKnight, 1993). Il s’appuie aussi sur des références qui rappellent la prudence nécessaire lorsqu’on décrit des personnes, des communautés et des savoirs : ne pas extraire, ne pas parler à la place des autres, situer les informations dans leurs relations et leurs contextes, et éviter de transformer un dossier en simple réservoir d’usage (Smith, 2021 ; Wilson, 2008 ; Kovach, 2021). Les références complètes se trouvent dans la bibliographie commentée.

---

## **2.7 Livrable du chapitre**

À la fin du chapitre, l’étudiant doit avoir produit :

* une situation choisie ;
* une double description de cette situation ;
* une première liste de ressources déjà présentes ;
* une première hypothèse sur ce qui a été mal vu, mal mobilisé, mal coordonné ou mal protégé.

Ce livrable reste volontairement simple. Il prépare le chapitre suivant, où ces ressources devront être nommées plus précisément, classées, situées et vérifiées.

---

## **2.8 Transition vers le chapitre 3**

Ce chapitre a déplacé le regard.

Il a montré qu’une situation ne doit pas être décrite seulement par ses problèmes, même lorsque ces problèmes sont réels. Il a aussi montré qu’une critique devient plus forte lorsqu’elle identifie les ressources présentes, les capacités ignorées, les relations fragilisées et les dossiers oubliés.

Le chapitre suivant transformera cette première reconnaissance en outil plus structuré : une carte des ressources.

Après avoir appris à voir ce qui existe déjà, il faut maintenant apprendre à l’inventorier de manière précise : qui porte quelles ressources, où elles se trouvent, à quelles conditions elles peuvent être mobilisées, et quelles limites doivent être respectées.
