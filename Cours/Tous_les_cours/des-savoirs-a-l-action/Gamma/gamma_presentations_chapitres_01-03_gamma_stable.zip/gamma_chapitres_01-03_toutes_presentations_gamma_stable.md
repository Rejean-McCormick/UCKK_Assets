<!-- Présentation Gamma : gamma_chapitre_01_01_introduction_generale_gamma_stable.md -->

# **01. Introduction générale**

**Rôle du chapitre :** Orienter

## **1.0 Objectifs du chapitre**

À la fin de ce chapitre, l’étudiant devrait être capable de :

* expliquer à quoi sert le guide ;
* distinguer la méthode générale du cours et le cas filé utilisé pour l’apprendre ;
* comprendre la transformation centrale du manuel ;
* nommer les principales précautions éthiques et méthodologiques ;
* décrire le travail final en termes simples ;
* retenir les premières confusions à éviter.

---

## **1.1 Situer — Pourquoi ce guide existe**
### **1.1.1 Idée centrale**

Ce guide propose une méthode pour passer d’une situation confuse à une compréhension plus claire, puis d’une compréhension plus claire à une action prudente, documentée et révisable.

Dans beaucoup de dossiers collectifs, le problème n’est pas seulement l’absence d’information. Le problème est souvent la faiblesse des passages entre ce qui existe déjà et ce qui devient réellement utile. Des informations circulent, mais restent dispersées. Des personnes savent, mais ne sont pas suffisamment écoutées. Des ressources existent, mais ne sont pas reconnues à temps. Des décisions sont prises, mais leurs effets ne sont pas bien suivis. Des traces s’accumulent, mais ne deviennent pas mémoire utile.

### **1.1.1 Idée centrale** (suite)

Le guide existe pour travailler ces passages. Il n’enseigne pas comment imposer une réponse rapide. Il enseigne comment construire une démarche responsable à partir d’éléments déjà présents : ressources, observations, témoignages, contraintes, désaccords, options, limites et traces.

---

### **1.1.2 Contexte de départ**

Le point de départ du cours est simple : beaucoup de situations échouent moins par manque absolu de matière que par défaut d’organisation, d’écoute, de distinction, de choix explicite et de mémoire. On agit trop vite, ou trop tard. On confond hypothèse et fait. On traite une solution comme si elle allait de soi. On oublie de prévoir les impacts. On archive sans réellement apprendre.

Ce guide répond à cette difficulté en proposant une progression contrôlée. L’étudiant apprendra à observer, écouter, inventorier, distinguer, comparer, choisir, agir, corriger et transmettre prudemment. Cette logique rejoint l’ambition pédagogique de l’UCKK : transformer des savoirs en capacité d’agir, sans confondre l’école avec l’ensemble du mouvement kOA.

---

### **1.1.3 Ce que le guide cherche à former**

Le guide cherche à former une posture de travail plutôt qu’un réflexe d’opinion. L’étudiant doit apprendre à :

* ralentir avant de conclure ;
* reconnaître ce qui existe déjà avant d’annoncer ce qui manque ;
* distinguer les éléments d’un dossier au lieu de les mélanger ;
* explorer plusieurs options au lieu de courir vers la première ;
* rendre un choix explicable ;
* transformer une décision en premier geste concret ;
* garder une trace utile de ce qui a été appris.

Autrement dit, le guide ne forme pas seulement à analyser. Il forme à faire passer une matière dispersée vers une action responsable, puis vers une mémoire réutilisable.

---

### **1.1.4 Phrase d’orientation**

Ce guide n’enseigne pas comment imposer une solution. Il enseigne comment préparer une action responsable à partir de ressources, d’observations, de choix prudents et de traces utiles.

## **1.2 Distinguer — Ce que le guide est et n’est pas**

### **1.2.1 Ce que le guide est**

Ce guide est :

* un guide d’apprentissage ;
* une méthode de clarification ;
* une préparation à l’action prudente ;
* un outil de production progressive ;
* une aide à la décision révisable ;
* une manière d’organiser des traces pour qu’elles deviennent utiles.

Il aide l’étudiant à passer d’un dossier dispersé à une compréhension plus solide, puis d’une compréhension plus solide à une action mieux justifiée. Il insiste sur la relation entre méthode, responsabilité et contexte. Cette prudence rejoint les approches non extractives et relationnelles, qui rappellent qu’un savoir ne peut pas être séparé de ses conditions d’usage, des personnes concernées et des responsabilités qui accompagnent sa circulation (Smith, 2021 ; Wilson, 2008 ; Kovach, 2021).

---

### **1.2.2 Ce que le guide n’est pas**

Ce guide n’est pas :

* un protocole universel ;
* un document de gouvernance kOA ;
* un manuel sur les cultures autochtones ;
* un outil d’extraction des savoirs ;
* une procédure pour décider à la place des personnes concernées ;
* une autorisation de recueillir, utiliser ou diffuser des informations sensibles ;
* un manuel technique sur l’intelligence artificielle ;
* un remplacement des règles locales, professionnelles, juridiques ou éthiques.

Il ne donne pas le droit de parler à la place des autres. Il ne transforme pas une information disponible en information librement réutilisable. Il ne dispense jamais de vérifier les autorisations, les limites de diffusion, les contextes de production ni les responsabilités de protection.

---

### **1.2.2 Ce que le guide n’est pas** (suite)

Cette vigilance rejoint les principes de consentement, d’engagement communautaire, de gouvernance des données et de responsabilité présents dans l’EPTC 2, OCAP® et les principes CARE (Groupe en éthique de la recherche, 2022 ; First Nations Information Governance Centre, n.d. ; Carroll et al., 2020).

---

### **1.2.3 Distinctions importantes à garder dès le départ**

Plusieurs confusions doivent être évitées dès l’ouverture du cours.

| À ne pas confondre | Pourquoi c’est important |
| :---- | :---- |
| Information / connaissance | Une information doit être située, vérifiée et interprétée avant d’être tenue pour solide. |
| Écoute / extraction | Écouter ne donne pas automatiquement le droit d’utiliser, citer ou diffuser. |
| Hypothèse / fait | Une hypothèse peut orienter l’enquête, mais elle ne doit pas être présentée comme un fait établi. |
| Solution / choix responsable | Une solution doit être comparée, justifiée et limitée avant de devenir un choix. |
| Action / impact | Une action produit des effets directs, indirects et parfois invisibles. |
| Archive / mémoire utile | Une archive n’aide pas automatiquement à mieux agir ; elle doit être organisée, contextualisée et protégée. |
| Critique / accusation | Une critique peut ouvrir l’analyse ; une accusation exige des preuves et une qualification plus rigoureuse. |

---

### **1.2.3 Distinctions importantes à garder dès le départ** (suite)

Dans le Grand Dossier COVID, ces distinctions sont décisives. Dire qu’une mesure a produit des effets négatifs n’est pas la même chose que démontrer qu’elle était injustifiée. Dire qu’une institution a mal communiqué n’est pas la même chose que prouver une intention de nuire. Dire qu’une population a perdu confiance n’explique pas encore pourquoi cette confiance s’est brisée.

---

### **1.2.4 Point de vigilance**

Tout ce qui existe, se dit ou se trouve dans un dossier n’est pas automatiquement utilisable, partageable ou réutilisable.

## **1.3 Transformer — La transformation centrale du guide**

### **1.3.1 Schéma central**

Information dispersée
*→ compréhension prudente*
*→ choix justifié*
*→ action responsable*
*→ mémoire utile*

---

### **1.3.2 Explication simple**

**Information dispersée → compréhension prudente**
L’étudiant commence par reconnaître ce qui existe déjà : personnes, ressources, documents, récits, données, critiques, expériences et traces. Il apprend à situer les sources, à écouter avec méthode et à distinguer les faits des hypothèses.

**Compréhension prudente → choix justifié**
Une fois la situation mieux comprise, l’étudiant n’est pas invité à courir vers la première solution. Il doit explorer plusieurs options, les comparer et retenir un choix qu’il peut expliquer.

***Choix justifié → action responsable***
*Un choix doit ensuite devenir un premier geste concret : qui fait quoi, avec quelles ressources, dans quel délai, avec quelles limites et quelles responsabilités.*

---

### **1.3.2 Explication simple** (suite)

**Action responsable → mémoire utile**
Enfin, une action responsable laisse une trace utilisable. Elle permet de retenir ce qui a été tenté, ce qui a fonctionné, ce qui a échoué, ce qui doit être corrigé et ce qui doit être transmis ou protégé.

Chaque passage demande une méthode. Une information ne devient pas automatiquement une compréhension. Une compréhension ne devient pas automatiquement un choix. Un choix ne devient pas automatiquement une action. Une action ne devient pas automatiquement une mémoire.

---

### **1.3.3 Lien avec le standard UCKK**

Le guide suit le standard pédagogique UCKK : orienter, situer, distinguer, transformer, produire, évaluer, mémoriser, projeter et référencer. Il ne s’agit pas seulement de présenter des notions. Il s’agit d’apprendre des passages contrôlés entre matière, compréhension, décision, action et mémoire.

Cette logique rejoint aussi le cycle kOA :

Connaître
*→ Choisir*
*→ Agir*
*→ Se souvenir*

Le manuel reprend cette dynamique dans un cadre pédagogique : il forme à rendre ces passages plus lisibles, plus prudents et plus révisables.

### **1.3.4 Phrase à retenir**

Une démarche responsable ne saute pas directement du problème à la solution. Elle passe par les ressources, l’écoute, la clarification, l’exploration, le choix, l’action et la mémoire.

---

## **1.4 Produire — Ce que l’étudiant devra faire**
### **1.4.1 Le cas filé du cours**

Le guide utilise le **Grand Dossier COVID** comme cas filé principal.

Le but n’est pas de trancher toutes les controverses médicales, scientifiques ou politiques liées à la pandémie. Le but est d’étudier une crise réelle dans laquelle des sociétés ont dû connaître rapidement, choisir sous pression, agir à grande échelle et se souvenir de ce qui avait été appris.

Le cas part d’une hypothèse critique : la gestion de la pandémie a révélé des faiblesses importantes de préparation, de communication, de proportionnalité, d’écoute, de suivi des impacts et de mémoire institutionnelle. Cette hypothèse ne doit pas être répétée comme un slogan. Elle doit être travaillée comme un dossier.

La règle de méthode est donc la suivante :

La critique est permise. L’accusation doit être documentée. L’indignation doit être transformée en méthode.

---

### **1.4.1 Le cas filé du cours** (suite)

L’étudiant choisira un angle précis du Grand Dossier COVID — par exemple les écoles, les aînés, la santé mentale, les travailleurs essentiels, la communication publique, les décisions locales, les données disponibles, les bilans post-crise ou la mémoire institutionnelle — afin d’appliquer une méthode générale à un cas concret.

---

### **1.4.2 Travail final annoncé**

Le travail final du cours consistera à transformer un aspect du Grand Dossier COVID en piste d’action responsable.

L’étudiant n’aura pas à produire une vérité totale sur la pandémie. Il devra produire une démarche claire, prudente, documentée et révisable à partir d’un angle précis.

---

### **1.4.3 Les éléments du travail final**

Le travail final comprendra :

1. une situation choisie ;
2. un inventaire des ressources existantes ;
3. des notes d’écoute ou d’observation ;
4. une distinction entre faits, hypothèses et interprétations ;
5. un inventaire de solutions possibles ;
6. un choix justifié ;
7. une prévision des impacts ;
8. un plan d’action minimal ;
9. un dossier dormant ou une information existante à réactiver ;
10. une proposition de mémoire utile ;
11. un retour réflexif sur la manière de connaître, choisir, agir et se souvenir.

---

### **1.4.4 Livrables intermédiaires**

Les productions seront construites progressivement.

| Partie du guide | Production principale |
| :---- | :---- |
| Partie 1 | Carte des ressources et notes d’écoute |
| Partie 2 | Inventaire des solutions et choix justifié |
| Partie 3 | Plan d’action et grille d’impacts |
| Partie 4 | Fiche de dossier dormant et mémoire utile |
| Partie 5 | Travail final assemblé |

Chaque chapitre ajoutera donc une pièce identifiable au dossier final. Le manuel ne demande pas seulement de réfléchir ; il demande de produire des traces réutilisables.

---

### **1.4.5 Attente principale**

Le travail final ne sera pas évalué parce qu’il propose une solution parfaite, mais parce qu’il montre une démarche claire, prudente, responsable et révisable.

## **1.5 Retenir — Les phrases clés de l’introduction**

### **1.5.1 Phrase maîtresse**

Le but n’est pas de produire une réponse parfaite. Le but est de produire une démarche claire, prudente, révisable et utile.

---

### **1.5.2 Formule courte du guide**

Inventorier avant d’analyser.
Écouter avant d’interpréter.
Explorer avant de choisir.
Prévoir avant d’agir.
Documenter avant de réutiliser.

### **1.5.3 Ce que l’étudiant doit retenir**

À la fin de l’introduction, l’étudiant doit comprendre que :

* comprendre demande du temps ;
* écouter ne veut pas dire posséder ;
* une information disponible n’est pas automatiquement utilisable ;
* une solution doit être comparée ;
* une action doit prévoir ses impacts ;
* une mémoire utile protège autant qu’elle transmet.

---

### **1.5.4 Erreurs à éviter dès le départ**

Dès l’ouverture du guide, plusieurs erreurs doivent être évitées :

* vouloir résoudre trop vite ;
* croire qu’une information disponible est automatiquement réutilisable ;
* traiter un silence comme une absence d’information ;
* confondre hypothèse et fait ;
* oublier les ressources déjà présentes ;
* produire un plan sans prévoir les impacts ;
* confondre archive et mémoire utile ;
* utiliser le vocabulaire de la justice, de la responsabilité ou de la décolonisation de manière vague ou décorative (Tuck & Yang, 2012).

---

## **1.6 Référencer — Références mobilisées dans l’introduction**
### **1.6.1 Références de fond**

Cette introduction s’appuie notamment sur :

### **1.6.1 Références de fond** (suite)

* **Linda Tuhiwai Smith** — pour la critique des recherches extractives, la prudence méthodologique et la responsabilité envers les savoirs situés ;
* **Shawn Wilson** — pour l’idée que la recherche est relationnelle et engage une responsabilité envers les personnes, les lieux et les savoirs ;
* **Margaret Kovach** — pour l’importance de la conversation, du contexte, du récit et de la validation dans les méthodologies autochtones ;
* **Tuck & Yang** — pour la vigilance contre les usages vagues, décoratifs ou dépolitisés de la décolonisation ;
* **EPTC 2** — pour les principes de consentement, d’engagement communautaire, de respect et de protection des savoirs dans la recherche avec des êtres humains ;
* **OCAP®** — pour la propriété, le contrôle, l’accès et la possession des informations des Premières Nations ;
* **CARE** — pour les droits collectifs, l’autorité de contrôle, la responsabilité et l’éthique dans la gouvernance des données.

---

### **1.6.2 Formule de fin de chapitre**

Cette introduction s’appuie notamment sur Smith, Wilson, Kovach, Tuck & Yang, l’EPTC 2, OCAP® et les principes CARE. Voir la bibliographie commentée pour les références complètes.

## **1.7 Transition vers le chapitre 2**

Ce chapitre a orienté le guide : il a présenté la méthode, le cas filé, les premières distinctions et le travail final.

Le chapitre suivant commencera le travail concret. Avant de dénoncer ce qui manque, il faudra apprendre à reconnaître ce qui existe déjà.

Dans le Grand Dossier COVID, cela signifie poser une question plus exigeante que *qu’est-ce qui a échoué ?* :

Quelles ressources existaient déjà, mais ont été mal vues, mal mobilisées, mal coordonnées ou mal respectées ?


<!-- FIN DE PRÉSENTATION / DÉBUT DE LA SUIVANTE -->


<!-- Présentation Gamma : gamma_chapitre_02_02_commencer_par_ce_qui_existe_deja_gamma_stable.md -->

# **02. Commencer par ce qui existe déjà**

**Rôle du chapitre :** Situer

**Trajectoire du chapitre :**

Diagnostic par les manques
*→ reconnaissance des ressources déjà présentes*
*→ première posture d’attention responsable*

## **2.0 Objectifs du chapitre**

À la fin de ce chapitre, l’étudiant devrait être capable de :

* reconnaître qu’une situation ne se résume pas à ses problèmes ;
* repérer les ressources déjà présentes dans un milieu ;
* distinguer problème, contexte, manque, ressource, capacité et urgence ;
* reformuler une situation sans réduire les personnes à leurs difficultés ;
* produire une première description orientée vers les ressources ;
* appliquer cette posture au Grand Dossier COVID.

Ce chapitre ouvre la première partie du guide. Il ne demande pas encore de choisir une solution. Il demande d’apprendre à voir autrement : avant d’ajouter, de corriger ou de dénoncer, il faut reconnaître ce qui existe déjà. Cette fonction, cette progression et cette hiérarchie de titres suivent le standard retenu pour le guide.

---

## **2.1 Situer — Le réflexe de commencer par les problèmes**

### **2.1.1 Idée centrale**

Beaucoup de démarches commencent par une question apparemment évidente :

Quel est le problème ?

Cette question peut être utile. Elle permet de nommer une difficulté, une tension, une urgence ou une souffrance. Mais si elle est posée seule, elle déforme le regard. Elle pousse à voir d’abord les déficits, les blessures, les absences et les dysfonctionnements.

Une situation devient alors un inventaire de manques :

* manque de personnel ;
* manque de coordination ;
* manque d’information ;
* manque de confiance ;
* manque de préparation ;
* manque de ressources ;
* manque de temps ;
* manque de leadership.

Ces manques peuvent être réels. Le problème n’est pas de les nommer. Le problème est de ne voir qu’eux.

---

### **2.1.2 Pourquoi ce réflexe pose problème**

Une lecture uniquement déficitaire produit souvent plusieurs effets :

* elle décrit les personnes à partir de ce qui leur manque ;
* elle sous-estime les savoirs déjà présents ;
* elle oublie les relations locales ;
* elle rend invisibles les capacités du milieu ;
* elle prépare trop vite une solution extérieure ;
* elle transforme les personnes concernées en objets d’intervention ;
* elle affaiblit la qualité même de la critique.

---

### **2.1.2 Pourquoi ce réflexe pose problème** (suite)

L’approche du développement communautaire fondé sur les ressources rappelle qu’un milieu ne doit pas être abordé uniquement par ses déficits, mais aussi par ses capacités, ses relations et ses appuis déjà présents (Kretzmann & McKnight, 1993). Dans le même esprit, les méthodologies relationnelles et non extractives insistent sur le fait qu’on ne comprend pas une situation en réduisant les personnes à leurs blessures ou à leurs manques ; il faut aussi reconnaître les contextes, les relations, les savoirs situés et les conditions d’usage de ce qui est observé (Smith, 2021 ; Wilson, 2008 ; Kovach, 2021).

---

### **2.1.3 Application au Grand Dossier COVID**

Dans le Grand Dossier COVID, le réflexe immédiat consiste souvent à commencer par les défaillances :

* les règles ont changé ;
* les messages ont parfois été contradictoires ;
* des personnes ont été isolées ;
* des familles ont été épuisées ;
* des travailleurs ont été exposés ;
* des impacts sociaux ont été mal anticipés ;
* la confiance envers les institutions a été fragilisée.

Ces constats peuvent être importants. Mais une critique qui s’arrête là reste incomplète.

La question de ce chapitre est plus exigeante :

Quelles ressources existaient déjà, mais ont été mal vues, mal mobilisées, mal coordonnées, mal protégées ou mal respectées ?

---

### **2.1.3 Application au Grand Dossier COVID** (suite)

Poser cette question ne blanchit pas les erreurs. Au contraire, cela les rend plus lisibles. Une gestion de crise peut être critiquée plus fortement lorsqu’on montre non seulement ce qui a manqué, mais aussi ce qui existait déjà et n’a pas été suffisamment reconnu. C’est le rôle du cas filé dans ce chapitre.

---

## **2.2 Distinguer — Problème, contexte, manque, ressource, capacité**
### **2.2.1 Distinctions de base**

Commencer par ce qui existe déjà exige des distinctions simples. Sans elles, l’étudiant risque de confondre plusieurs réalités.

### **2.2.1 Distinctions de base** (suite)

| À distinguer | Pourquoi c’est important |
| :---- | :---- |
| Problème / contexte | Le problème est ce qui dérange. Le contexte aide à comprendre pourquoi cela arrive. |
| Manque / ressource | Un manque signale une absence. Une ressource indique un appui possible pour comprendre ou agir. |
| Vulnérabilité / capacité | Une personne peut vivre une difficulté tout en portant des savoirs, des compétences ou des relations importantes. |
| Besoin / potentiel | Un besoin appelle une réponse. Un potentiel indique une possibilité à développer ou à soutenir. |
| Ressource / solution | Une ressource peut soutenir l’action, mais elle n’est pas encore une solution. |
| Existence / disponibilité | Une ressource peut exister sans être accessible, autorisée, coordonnée ou utilisable. |
| Urgence / priorité | Ce qui est urgent attire l’attention, mais n’épuise pas toujours ce qui est important. |

---

### **2.2.2 Deux erreurs opposées**

Ce chapitre veut éviter deux erreurs opposées.

**Première erreur :** ne voir que les problèmes.
On obtient alors un diagnostic brutal, parfois juste, mais appauvri. Les personnes sont décrites par leurs limites et le milieu paraît vide.

**Deuxième erreur :** idéaliser les ressources.
On parle alors de forces sans nommer les contraintes, les conflits, l’épuisement, l’inégalité d’accès ou les limites d’usage.

La posture juste n’est ni le déni du problème ni l’éloge abstrait des forces. Elle consiste à tenir ensemble :

* les difficultés réelles ;
* les ressources déjà présentes ;
* les limites de ces ressources ;
* les conditions de leur mobilisation.

---

### **2.2.3 Une ressource n’est pas automatiquement utilisable**

Une ressource peut exister sans être :

* visible ;
* coordonnée ;
* disponible au bon moment ;
* accessible à tous ;
* légitime dans le contexte ;
* partageable sans risque ;
* suffisante pour répondre seule au problème.

Autrement dit :

ce qui existe déjà n’est pas automatiquement mobilisable.

Cette distinction est importante pour la suite du guide. Elle prépare le passage du chapitre 2 au chapitre 3 : voir les ressources ne suffit pas, il faudra ensuite les inventorier, les situer, préciser qui les porte, à quelles conditions elles peuvent être mobilisées et quelles précautions doivent être respectées.

---

## **2.3 Transformer — Changer le regard avant d’agir**

### **2.3.1 La transformation centrale du chapitre**

La transformation de ce chapitre est simple, mais décisive :

*description par les manques → description par les ressources*

Ce déplacement ne supprime pas la critique. Il l’améliore.

Une critique faible dit seulement :

rien n’allait.

Une critique plus forte demande :

* qu’est-ce qui manquait réellement ;
* qu’est-ce qui existait déjà ;
* qui portait ces ressources ;
* pourquoi elles n’ont pas suffi ;
* pourquoi elles n’ont pas été reconnues, coordonnées ou protégées ;
* quelles relations ont été ignorées ;
* quelles capacités ont été sous-estimées.

---

### **2.3.2 Ce que ce changement produit**

Changer le regard avant d’agir permet de :

* décrire une situation avec plus de justesse ;
* éviter de réduire les personnes à leurs blessures ;
* identifier des appuis déjà présents ;
* préparer une critique plus documentée ;
* éviter de proposer trop vite une solution importée ;
* mieux voir ce qui devra être inventorié au chapitre suivant.

Dans le cas du Grand Dossier COVID, ce changement de regard mène d’une formule vague — *tout a mal été géré* — à une question de travail plus précise :

Quels appuis existaient déjà dans les institutions, les milieux de vie, les communautés, les familles, les territoires et les documents, et qu’est-ce qui a empêché qu’ils soutiennent mieux l’action ?

---

### **2.3.3 Exemples de ressources à reconnaître dans le cas COVID**

Selon l’angle étudié, les ressources déjà présentes pouvaient inclure :

* des plans de pandémie ;
* des équipes de santé publique ;
* des soignants de terrain ;
* des pharmaciens ;
* des enseignants ;
* des directions d’école ;
* des organismes communautaires ;
* des familles ;
* des proches aidants ;
* des municipalités ;
* des réseaux de bénévoles ;
* des radios locales ;
* des lieux de distribution ;
* des données hospitalières ;
* des bilans locaux ;
* des critiques précoces ;
* des savoirs pratiques issus du terrain ;
* des documents oubliés ou peu relus.

Le travail de l’étudiant n’est pas encore de tout classer. Il est d’apprendre à voir que le terrain n’est pas vide. Le chapitre 3 transformera cette reconnaissance en carte des ressources. Le cas filé prévoit explicitement ce passage d’une critique générale de la crise à une question plus précise sur les ressources mal reconnues ou mal mobilisées.

---

## **2.4 Produire — Exercice de double description**

### **2.4.1 Consigne**

Choisis une situation précise liée au Grand Dossier COVID.

Exemples possibles :

* fermetures d’écoles ;
* isolement des aînés ;
* communication publique ;
* surcharge du personnel soignant ;
* fatigue parentale ;
* travailleurs essentiels ;
* accès inégal au numérique ;
* perte de confiance envers les institutions.

Rédige ensuite **deux descriptions courtes** de la même situation.

---

### **2.4.2 Description A — Lecture par les manques**

Écris un court paragraphe qui décrit la situation en commençant par ce qui manque, ce qui échoue ou ce qui est brisé.

### **2.4.3 Description B — Lecture par les ressources**

Réécris ensuite la même situation en commençant par les ressources déjà présentes, sans nier les problèmes.

Ta seconde description doit essayer de répondre aux questions suivantes :

* qui ou quoi était déjà là ;
* quels savoirs existaient déjà ;
* quelles relations pouvaient soutenir l’action ;
* quelles institutions, quels lieux ou quels documents pouvaient servir d’appui ;
* quelles ressources ont été mal vues, mal coordonnées ou mal respectées ;
* quelles limites empêchaient leur mobilisation complète.

---

### **2.4.4 Exemple appliqué**

**Situation choisie :** fatigue des familles pendant les fermetures d’écoles.

**Description A — par les manques**

Les fermetures d’écoles ont épuisé les familles. Il manquait de stabilité, de soutien, de répit, d’accompagnement et de coordination. Les parents ont dû tout porter à la fois, souvent sans aide suffisante.

**Description B — par les ressources**

Les familles n’étaient pas seules à partir de rien. Il existait déjà des enseignants, des directions d’école, des organismes jeunesse, des réseaux de parents, des outils numériques, des professionnels psychosociaux, des lieux communautaires et des expériences locales de soutien. Le problème n’était pas seulement l’absence de ressources ; c’était aussi leur coordination inégale, leur accessibilité variable, leur surcharge et le fait que certaines d’entre elles ont été trop peu reconnues ou trop tard mobilisées.

---

### **2.4.5 Grille rapide pour l’exercice**

| Élément à repérer | Question |
| :---- | :---- |
| Problème visible | Qu’est-ce qui semble manquer ou échouer ? |
| Ressources présentes | Qui ou quoi était déjà là ? |
| Porteurs | Qui porte réellement ces ressources ? |
| Conditions | À quelles conditions ces ressources sont-elles accessibles ? |
| Limites | Pourquoi ces ressources n’ont-elles pas suffi ? |
| Hypothèse de travail | Qu’est-ce que cette double description change dans la compréhension de la situation ? |

---

## **2.5 Retenir — Ce qu’il faut garder du chapitre**

### **2.5.1 Phrase clé**

Commencer par ce qui existe déjà ne nie pas les problèmes ; cela empêche de mal voir la situation.

### **2.5.2 Ce que l’étudiant doit retenir**

À la fin du chapitre, l’étudiant doit comprendre que :

* une situation ne se résume pas à ses manques ;
* une critique plus forte identifie aussi les ressources ignorées ;
* une ressource n’est pas une solution ;
* ce qui existe n’est pas automatiquement disponible ;
* les personnes concernées ne doivent pas être réduites à leurs difficultés ;
* le regard posé au départ influence toute la suite du travail.

---

### **2.5.3 Erreurs fréquentes**

* croire que regarder les ressources revient à minimiser les dommages ;
* faire l’éloge abstrait des forces sans nommer les limites ;
* confondre ressource et solution ;
* prendre une ressource existante pour une ressource accessible ;
* réduire une population à ses souffrances ;
* dénoncer une crise sans demander quelles capacités avaient déjà été négligées.

---

## **2.6 Référencer — Références mobilisées**

Ce chapitre s’appuie principalement sur l’approche du développement communautaire fondé sur les ressources, qui invite à commencer par les capacités existantes d’un milieu plutôt que par ses seuls déficits (Kretzmann & McKnight, 1993). Il s’appuie aussi sur des références qui rappellent la prudence nécessaire lorsqu’on décrit des personnes, des communautés et des savoirs : ne pas extraire, ne pas parler à la place des autres, situer les informations dans leurs relations et leurs contextes, et éviter de transformer un dossier en simple réservoir d’usage (Smith, 2021 ; Wilson, 2008 ; Kovach, 2021). Les références complètes se trouvent dans la bibliographie commentée.

---

## **2.7 Livrable du chapitre**

À la fin du chapitre, l’étudiant doit avoir produit :

* une situation choisie ;
* une double description de cette situation ;
* une première liste de ressources déjà présentes ;
* une première hypothèse sur ce qui a été mal vu, mal mobilisé, mal coordonné ou mal protégé.

Ce livrable reste volontairement simple. Il prépare le chapitre suivant, où ces ressources devront être nommées plus précisément, classées, situées et vérifiées.

---

## **2.8 Transition vers le chapitre 3**

Ce chapitre a déplacé le regard.

Il a montré qu’une situation ne doit pas être décrite seulement par ses problèmes, même lorsque ces problèmes sont réels. Il a aussi montré qu’une critique devient plus forte lorsqu’elle identifie les ressources présentes, les capacités ignorées, les relations fragilisées et les dossiers oubliés.

Le chapitre suivant transformera cette première reconnaissance en outil plus structuré : une carte des ressources.

Après avoir appris à voir ce qui existe déjà, il faut maintenant apprendre à l’inventorier de manière précise : qui porte quelles ressources, où elles se trouvent, à quelles conditions elles peuvent être mobilisées, et quelles limites doivent être respectées.


<!-- FIN DE PRÉSENTATION / DÉBUT DE LA SUIVANTE -->


<!-- Présentation Gamma : gamma_chapitre_03_03_inventorier_les_ressources_gamma_stable.md -->

# **03. Inventorier les ressources**

**Rôle du chapitre :** *Situer → Produire*

**Trajectoire du chapitre :**
Situation vague
*→ ressources repérées*
*→ ressources classées*
*→ porteurs identifiés*
*→ accès clarifiés*
*→ limites reconnues*
*→ carte des ressources disponible*

## **3.0 Objectifs du chapitre**

À la fin de ce chapitre, l’étudiant devrait être capable de :

* repérer les ressources déjà présentes dans une situation ;
* distinguer ressource, besoin et solution ;
* classer les ressources sans transformer l’inventaire en catalogue confus ;
* identifier qui porte une ressource et sous quelles conditions elle peut être mobilisée ;
* reconnaître les ressources visibles, invisibles, dormantes ou sensibles ;
* produire une carte des ressources utile pour la suite du travail.

Ce chapitre transforme le déplacement de regard du chapitre 2 en premier outil concret. On ne reste plus seulement dans la posture. On commence à construire une base de travail.

---

## **3.1 Situer — Avant d’agir, savoir ce qui existe**

### **3.1.1 Idée centrale**

Avant de demander ce qu’il faut ajouter, il faut reconnaître ce qui est déjà là.

Une situation collective ne contient pas seulement des problèmes. Elle contient aussi des personnes, des compétences, des relations, des lieux, des documents, des outils, des habitudes, des savoir-faire, des expériences passées et parfois des ressources oubliées. L’approche du développement communautaire fondé sur les ressources rappelle qu’un milieu ne doit pas être abordé uniquement par ses déficits, mais aussi par ses capacités déjà présentes (Kretzmann & McKnight, 1993).

Inventorier les ressources ne veut pas dire nier les difficultés. Cela veut dire éviter une erreur fréquente : confondre diagnostic sérieux et regard uniquement déficitaire.

---

### **3.1.2 Pourquoi commencer par les ressources**

Commencer par les ressources change la qualité de l’analyse.

Une lecture centrée seulement sur les manques conduit souvent à :

* sous-estimer les personnes concernées ;
* ignorer des appuis déjà disponibles ;
* proposer trop vite une solution extérieure ;
* répéter un travail déjà fait ;
* confondre absence de coordination et absence totale de ressources.

À l’inverse, un inventaire des ressources permet de demander :

* qu’est-ce qui existe déjà ;
* qui le porte ;
* à quoi cela peut servir ;
* dans quelles conditions cela peut être mobilisé ;
* quelles limites ou protections doivent être respectées.

Cette manière de voir prépare une action plus située, plus prudente et plus réaliste. Elle rejoint aussi les approches relationnelles de la connaissance : une ressource n’a de sens qu’en lien avec un contexte, des personnes et des responsabilités (Wilson, 2008 ; Smith, 2021).

---

### **3.1.3 Place du chapitre dans le guide**

Le chapitre 2 a déplacé le regard : ne pas commencer seulement par les problèmes.

Le chapitre 3 transforme ce déplacement en production. Il fait apparaître une première trace structurée : **la carte des ressources**.

Cette carte n’est pas encore une solution. Elle sert à mieux voir le terrain avant d’écouter plus finement les personnes, puis avant de distinguer les faits, hypothèses et interprétations. La structure attendue du chapitre et sa fonction de première vraie production sont explicitement prévues dans l’outline détaillé et dans le standard de numérotation retenu.

---

### **3.1.4 Application au Grand Dossier COVID**

Dans le Grand Dossier COVID, l’inventaire des ressources empêche de réduire la crise à une liste d’échecs. Il oblige à demander :

* quelles ressources existaient déjà avant la crise ;
* lesquelles ont été mobilisées ;
* lesquelles ont été ignorées ;
* lesquelles ont été surchargées ;
* lesquelles étaient présentes mais mal coordonnées ;
* lesquelles demeurent sensibles ou difficiles à réutiliser.

Exemples de ressources à repérer :

* plans de pandémie ;
* santé publique ;
* médecins de terrain ;
* infirmières ;
* pharmaciens ;
* écoles ;
* organismes communautaires ;
* familles ;
* municipalités ;
* radios locales ;
* réseaux de bénévoles ;
* savoirs issus d’épidémies précédentes ;
* données hospitalières ;
* lieux de distribution ;
* équipes logistiques ;
* experts critiques ;
* expériences locales.

---

## **3.2 Distinguer — Ressource, besoin, solution**

### **3.2.1 Distinctions importantes**

Avant de classer les ressources, il faut clarifier quelques distinctions simples.

| À distinguer | Pourquoi c’est important |
| :---- | :---- |
| Ressource / besoin | Une ressource est un appui existant ; un besoin indique ce qui manque ou ce qui doit être soutenu. |
| Ressource / solution | Une ressource peut aider à agir, mais elle n’est pas encore une stratégie ou une décision. |
| Présence / accès | Une ressource peut exister sans être réellement accessible. |
| Accès / permission | On peut pouvoir atteindre une ressource sans avoir le droit légitime de l’utiliser ou de la diffuser. |
| Visible / invisible | Certaines ressources sautent aux yeux ; d’autres passent par la confiance, les relations ou l’expérience locale. |
| Active / dormante | Une ressource peut être mobilisée maintenant, ou rester oubliée jusqu’à ce qu’on la relise. |
| Utile / sensible | Une ressource peut être précieuse, tout en exigeant prudence, protection ou validation. |

---

### **3.2.2 Définition de ressource**

Dans ce guide, une ressource est :

une personne, un groupe, une relation, un lieu, un document, une capacité, une expérience, un outil ou une trace qui peut soutenir la compréhension ou l’action, à condition que son usage soit situé, légitime et prudent.

Cette définition est volontairement large. Elle permet d’inclure à la fois des ressources matérielles et des ressources relationnelles, institutionnelles ou documentaires.

---

### **3.2.3 Les dix types de ressources**

Pour éviter l’effet catalogue, le chapitre utilise une typologie stable de dix types. Elle ne sert pas à compliquer l’analyse, mais à la rendre lisible.

1. **Ressources individuelles** — personnes, compétences, expériences, savoir-faire.
2. **Ressources communautaires** — organismes, groupes d’entraide, réseaux locaux.
3. **Ressources relationnelles** — liens de confiance, relais, proximités, personnes-ponts.
4. **Ressources institutionnelles** — services publics, écoles, municipalités, établissements.
5. **Ressources documentaires** — plans, bilans, rapports, statistiques, consignes, archives.
6. **Ressources logistiques** — lieux, matériel, transport, accès technique, distribution.
7. **Ressources territoriales** — proximité, dispersion, ancrage local, géographie du problème.
8. **Ressources culturelles et communicationnelles** — langues, codes, pratiques locales, médias de confiance.
9. **Ressources dormantes** — anciens bilans, plans oubliés, apprentissages non réactivés.
10. **Ressources sensibles** — données, témoignages, dossiers ou relations dont l’usage exige prudence, autorisation ou protection.

---

### **3.2.4 Ressources visibles et invisibles**

Une carte faible montre seulement les ressources officielles ou évidentes :

* institutions ;
* documents publics ;
* lieux connus ;
* programmes formels.

Une carte plus forte inclut aussi les ressources moins visibles :

* personnes de confiance ;
* savoirs pratiques ;
* expérience accumulée ;
* habitudes locales efficaces ;
* réseaux de solidarité ;
* relais informels ;
* mémoire collective.

Les approches centrées sur les dommages risquent de passer à côté de ces ressources moins visibles. Il faut donc apprendre à regarder aussi ce qui tient discrètement un milieu, sans pour autant l’idéaliser (Tuck, 2009).

---

### **3.2.5 Présence, accès, permission**

Une ressource peut être :

* présente sans être accessible ;
* accessible sans être librement réutilisable ;
* autorisée, mais trop fragile pour être mobilisée sans précaution.

| Question | Ce qu’elle vérifie | Exemple |
| :---- | :---- | :---- |
| La ressource est-elle présente ? | existence réelle de la ressource | un bilan existe-t-il vraiment ? |
| La ressource est-elle accessible ? | possibilité concrète d’y accéder | peut-on obtenir le document, joindre le service, utiliser le lieu ? |
| La ressource est-elle mobilisable avec permission ? | droit, autorisation, légitimité d’usage | a-t-on le droit d’utiliser cette donnée, cette parole, ce contact ? |

Cette distinction évite de confondre **présence** et **usage légitime**. Elle rejoint les garde-fous du guide : une information disponible n’est pas automatiquement librement réutilisable.

---

## **3.3 Transformer — De la liste à la carte**

### **3.3.1 Opération centrale**

L’opération du chapitre consiste à passer d’une liste dispersée à une **carte des ressources**.

Éléments repérés
*→ tri par type*
*→ porteurs identifiés*
*→ conditions précisées*
*→ limites reconnues*
*→ carte lisible pour la suite*

Une liste accumule. Une carte organise.

Une carte des ressources doit montrer au minimum :

* ce qui existe ;
* qui le porte ;
* à quoi cela peut servir ;
* sous quelles conditions cela peut être mobilisé ;
* ce qui doit être vérifié, protégé ou laissé de côté.

---

### **3.3.2 Étapes de transformation**

**Étape 1 — Repérer**
Lister rapidement les ressources déjà présentes, sans encore chercher l’ordre parfait.

**Étape 2 — Regrouper**
Classer les ressources par type pour éviter le mélange entre personnes, documents, lieux, données et relations.

**Étape 3 — Situer**
Identifier pour chaque ressource son porteur, son contexte et sa portée réelle.

**Étape 4 — Qualifier**
Préciser si la ressource est visible, invisible, dormante, sensible, accessible, partielle ou à vérifier.

**Étape 5 — Relire**
Se demander ce que la carte rend visible qui ne l’était pas au départ. Donald Schön rappelle que la compréhension se construit souvent en relisant l’action et ses traces, pas seulement en avançant linéairement (Schön, 1983).

---

### **3.3.3 Pourquoi cette transformation est nécessaire**

Sans cette transformation, l’étudiant risque :

* de garder une liste trop longue et inutilisable ;
* de confondre ressources fortes et ressources fragiles ;
* d’oublier les ressources invisibles ;
* de traiter toute ressource trouvée comme immédiatement mobilisable ;
* de ne pas voir ce qui manque en coordination plutôt qu’en existence ;
* de proposer une solution sans connaître réellement le terrain.

La carte n’est donc pas un luxe de présentation. C’est une manière de penser plus justement.

---

### **3.3.4 Le cas COVID comme exercice de lucidité**

Dans le cas du Grand Dossier COVID, transformer la liste en carte permet de passer d’une critique générale — *la crise a été mal gérée* — à une question plus utile :

Quelles ressources auraient pu soutenir une meilleure gestion si elles avaient été mieux reconnues, mieux coordonnées ou mieux respectées ?

Cette question rend la critique plus précise. Elle ne remplace pas l’analyse des erreurs ; elle la rend plus lisible.

---

### **3.3.5 Erreurs fréquentes**

* **Confondre ressource et solution.** Un organisme local n’est pas encore une stratégie.
* **Faire une liste trop longue et inutilisable.** Mieux vaut une carte claire qu’un inventaire sans hiérarchie.
* **N’inclure que les ressources officielles.** Les ressources relationnelles et locales comptent aussi.
* **Traiter toute ressource disponible comme automatiquement mobilisable.** L’accès et la permission doivent être vérifiés.
* **Oublier les ressources dormantes.** Un vieux plan, un ancien bilan ou une mémoire locale peuvent redevenir utiles.
* **Oublier les limites.** Une ressource peut être réelle, mais surchargée, partielle ou fragile.

---

### **3.3.6 Point de vigilance**

Une bonne carte ne sert pas à montrer qu’il existe beaucoup de choses. Elle sert à montrer **ce qui peut réellement compter pour comprendre et agir**, avec quelles conditions et quelles limites.

## **3.4 Produire — Carte des ressources**

### **3.4.1 Livrable principal**

Le livrable principal du chapitre est une **carte des ressources** liée à une situation précise.

Cette carte ne doit pas être une simple liste. Elle doit montrer :

* quelles ressources existent déjà ;
* qui les porte ;
* à quoi elles peuvent servir ;
* si elles sont réellement accessibles ;
* quelles permissions, limites ou précautions doivent être prises en compte.

La carte doit rester suffisamment courte pour être utile, mais suffisamment riche pour faire apparaître autre chose qu’un inventaire dispersé.

---

### **3.4.2 Tableau d’inventaire — Identifier les ressources**

Le premier tableau sert à nommer les ressources et à les situer.

| Ressource | Type | Porteur | À quoi cela peut servir |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Ce tableau répond à quatre questions simples :

* quelle est la ressource ;
* de quel type de ressource s’agit-il ;
* qui la porte ;
* à quoi elle peut servir.

---

### **3.4.3 Tableau d’inventaire — Vérifier les conditions d’usage**

Le second tableau sert à éviter une confusion importante : une ressource peut exister sans être réellement accessible, autorisée ou mobilisable.

| Ressource | Présente ? | Accessible ? | Permission, limite ou précaution |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Ce tableau répond à trois questions :

* la ressource existe-t-elle vraiment ;
* peut-on y accéder concrètement ;
* a-t-on le droit ou la légitimité de l’utiliser.

---

### **3.4.4 Tableau complémentaire — Ressources à vérifier**

Certaines ressources semblent importantes, mais ne peuvent pas encore être utilisées sans vérification.

| Ressource | Ce qui doit être vérifié | Qui peut valider ? | Prochaine étape |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Ce tableau sert à repérer les ressources qui demandent une étape supplémentaire avant d’être mobilisées.

---

### **3.4.5 Tableau complémentaire — Ressources sensibles**

Certaines ressources peuvent être utiles, mais elles exigent une protection particulière.

| Ressource | Pourquoi elle est sensible | Qui peut décider de son usage ? | Précaution |
| :---- | :---- | :---- | :---- |
|  |  |  |  |

Une ressource sensible n’est pas une ressource interdite.
C’est une ressource dont l’usage doit être encadré, limité ou validé.

---

### **3.4.6 Exemple appliqué au Grand Dossier COVID**

**Situation choisie :** effets des fermetures d’écoles sur les jeunes et leurs familles.

#### **A. Identification des ressources**

| Ressource | Type | Porteur | À quoi cela peut servir |
| :---- | :---- | :---- | :---- |
| enseignants | individuelle / institutionnelle | écoles | observer les besoins des jeunes au quotidien |
| parents | individuelle / relationnelle | familles | comprendre les effets à domicile |
| données scolaires | documentaire | établissements / services scolaires | repérer des signes d’absentéisme ou de décrochage |
| organismes jeunesse | communautaire | organismes locaux | offrir du soutien, du relais et de l’accompagnement |
| professionnels psychosociaux | individuelle / institutionnelle | réseau de santé / écoles | apporter une expertise clinique et un suivi |
| bilans post-crise | dormante / documentaire | institutions / chercheurs | réactiver des apprentissages déjà formulés |
| lieux communautaires | logistique / territoriale | municipalités / organismes | organiser des rencontres, du soutien ou des ateliers |
| relations de confiance | relationnelle | familles / quartiers / milieux | permettre une parole plus libre et une meilleure remontée d’information |

---

#### **B. Conditions d’usage**

| Ressource | Présente ? | Accessible ? | Permission, limite ou précaution |
| :---- | :---- | :---- | :---- |
| enseignants | Oui | Oui | usage légitime dans leur rôle ; attention à la surcharge |
| parents | Oui | Variable | consultation à organiser ; fatigue et diversité des situations |
| données scolaires | Oui | Partielle | usage encadré ; confidentialité à respecter |
| organismes jeunesse | Oui | Variable | selon les ententes locales ; capacité inégale selon les milieux |
| professionnels psychosociaux | Oui | Limitée | selon disponibilité ; délais et surcharge possibles |
| bilans post-crise | Oui | Variable | utilisables si source publique ou autorisée ; validité à vérifier |
| lieux communautaires | Oui | Variable | coordination locale nécessaire ; accès territorial inégal |
| relations de confiance | Oui | Fragile | non réutilisables sans prudence ; lentes à construire |

---

#### **C. Ressources à vérifier**

| Ressource | Ce qui doit être vérifié | Qui peut valider ? | Prochaine étape |
| :---- | :---- | :---- | :---- |
| données scolaires | niveau d’accès, degré d’agrégation et règles de confidentialité | établissements / services scolaires | identifier les données utilisables sans exposer les élèves |
| bilans post-crise | existence, date, portée et fiabilité | institutions / chercheurs | retrouver les bilans pertinents et vérifier leur actualité |
| organismes jeunesse | disponibilité réelle et capacité d’accueil | organismes locaux | vérifier les ressources encore actives et accessibles |

#### **D. Ressource sensible à protéger ou à encadrer**

| Ressource | Pourquoi elle est sensible | Qui peut décider de son usage ? | Précaution |
| :---- | :---- | :---- | :---- |
| données scolaires individuelles | elles peuvent exposer des élèves ou des familles | établissements / autorités responsables | anonymiser, limiter l’accès, vérifier les autorisations |

---

### **3.4.7 Mini-exercice**

À partir de la situation choisie :

1. écrire une liste brute d’au moins 20 ressources possibles ;
2. choisir les 8 à 12 ressources les plus utiles pour la carte ;
3. les classer dans les catégories du tableau ;
4. identifier au moins cinq porteurs de ressources ;
5. préciser les conditions d’accès ;
6. identifier au moins trois limites ou précautions ;
7. repérer au moins une ressource dormante ;
8. repérer au moins une ressource sensible ;
9. choisir trois ressources à vérifier avant de continuer.

**Production attendue :**

* le tableau d’identification des ressources ;
* le tableau des conditions d’usage ;
* le tableau des ressources à vérifier ;
* le tableau des ressources sensibles, si nécessaire ;
* une courte note de 8 à 10 lignes répondant à la question suivante :

**Qu’est-ce que cet inventaire m’a permis de voir que je n’aurais pas vu en commençant seulement par le problème ?**

---

### **3.4.8 Critères de réussite**

Le travail est réussi si la carte :

* distingue clairement les ressources des besoins et des solutions ;
* montre plusieurs types de ressources, pas une seule famille ;
* identifie les porteurs des ressources ;
* précise les conditions d’accès ;
* distingue présence, accessibilité et permission d’usage ;
* nomme les limites principales ;
* repère au moins une ressource dormante ou invisible ;
* repère au moins une ressource sensible, si elle existe ;
* reste lisible et utile pour la suite du travail.

Une bonne carte des ressources ne cherche pas à tout montrer.
Elle cherche à rendre visibles les appuis qui peuvent réellement compter pour comprendre et agir prudemment.

---

## **3.5 Retenir — Ce qu’une carte permet et ne permet pas**

### **3.5.1 Phrase clé**

Une carte des ressources ne résout pas le problème. Elle empêche de croire qu’il n’existe rien avant la solution.

### **3.5.2 Trois idées à retenir**

* Une situation contient plus que ses manques.
* Une ressource n’est utile que si son porteur, son accès et ses limites sont situés.
* Une bonne carte prépare l’écoute, la distinction et, plus tard, le choix.

---

### **3.5.3 Erreurs à éviter**

* réduire la situation à un inventaire de déficits ;
* transformer l’inventaire en catalogue trop long ;
* oublier les ressources invisibles ou dormantes ;
* confondre présence et permission ;
* produire une carte sans limites ni précautions.

### **3.5.4 Transition vers l’écoute**

Une carte des ressources ne suffit pas.

Elle montre ce qui existe, mais elle ne dit pas encore ce que les personnes vivent, comprennent, craignent, contestent ou jugent prioritaire.

Après avoir repéré les ressources, il faut donc apprendre à écouter.

---

## **3.6 Référencer — Références mobilisées**

### **3.6.1 Références principales**

Cette partie s’appuie notamment sur :

* **Kretzmann & McKnight** : développement communautaire fondé sur les ressources ;
* **Shawn Wilson** : savoir relationnel, contexte et responsabilité ;
* **Linda Tuhiwai Smith** : prudence méthodologique, non-extraction et conditions d’usage ;
* **Donald Schön** : compréhension progressive, relecture de l’action et apprentissage par ajustement.

---

### **3.6.2 Références secondaires possibles**

À mentionner seulement si nécessaire :

* **Eve Tuck** : ne pas réduire un milieu à ses dommages ;
* **Margaret Kovach** : contexte, conversation, récit et validation ;
* **OCAP® / CARE** : accès, autorité, contrôle, protection et gouvernance des informations.

Les références complètes se trouvent dans la bibliographie commentée.

---

## **3.7 Livrable du chapitre**

**Livrable attendu :** une carte des ressources de 8 à 12 entrées, liée à un angle précis du cas étudié.

**Format minimal attendu :**

* un titre de situation ;
* un tableau d’inventaire ;
* trois ressources à vérifier ;
* une ressource sensible à protéger ou à encadrer ;
* une courte note de lecture : *qu’est-ce que cette carte rend visible ?*

## **3.8 Transition vers le chapitre 4**

*03. Inventorier les ressources*
*→ 04. Écouter avec attention*

Une carte des ressources ouvre le terrain. L’écoute lui donne du sens.
